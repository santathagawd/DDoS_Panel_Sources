﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Resources;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyCompany("HoverCore")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2021")]
[assembly: AssemblyProduct("AstroStrike")]
[assembly: AssemblyTitle("AstroStrike")]
[assembly: AssemblyDescription("Multi-purpose application. Allows users to enjoy UI and features")]
[assembly: ComVisible(false)]
[assembly: AssemblyAssociatedContentFile("paping.exe")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyTrademark("HoverCore")]
[assembly: AssemblyFileVersion("1.0.0.0")]
