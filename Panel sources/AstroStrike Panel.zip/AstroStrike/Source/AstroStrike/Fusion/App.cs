﻿using System;

namespace Fusion
{
	// Token: 0x0200001B RID: 27
	public struct App
	{
		// Token: 0x040000E1 RID: 225
		public static string ActiveApis;

		// Token: 0x040000E2 RID: 226
		public static string ApiCount;

		// Token: 0x040000E3 RID: 227
		public static string UserCount;

		// Token: 0x040000E4 RID: 228
		public static string AppName;

		// Token: 0x040000E5 RID: 229
		public static string AppDescription;
	}
}
