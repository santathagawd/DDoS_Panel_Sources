﻿using System;

namespace Fusion
{
	// Token: 0x0200001C RID: 28
	public struct User
	{
		// Token: 0x040000E6 RID: 230
		public static string MfaCode;

		// Token: 0x040000E7 RID: 231
		public static string Ip;

		// Token: 0x040000E8 RID: 232
		public static string HardwareId;

		// Token: 0x040000E9 RID: 233
		public static int Level;

		// Token: 0x040000EA RID: 234
		public static string Expiry;

		// Token: 0x040000EB RID: 235
		public static string Username;

		// Token: 0x040000EC RID: 236
		public static string UserId;
	}
}
