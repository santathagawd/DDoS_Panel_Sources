﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace AstroStrike
{
	// Token: 0x02000025 RID: 37
	public partial class App : Application
	{
	}
}
