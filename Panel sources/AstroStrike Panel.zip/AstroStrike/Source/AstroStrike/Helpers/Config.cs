﻿using System;

namespace AstroStrike.Helpers
{
	// Token: 0x02000065 RID: 101
	public class Config
	{
		// Token: 0x0400031B RID: 795
		public static readonly string AppVersion = "1.1.2";

		// Token: 0x0400031C RID: 796
		public static readonly string AppID = "1555133";
	}
}
