﻿using System;

namespace AstroStrike.Modules
{
	// Token: 0x0200005A RID: 90
	public class Attack
	{
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060001EC RID: 492 RVA: 0x000028F5 File Offset: 0x00000AF5
		// (set) Token: 0x060001ED RID: 493 RVA: 0x000028FD File Offset: 0x00000AFD
		public string Target { get; set; }

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060001EE RID: 494 RVA: 0x00002906 File Offset: 0x00000B06
		// (set) Token: 0x060001EF RID: 495 RVA: 0x0000290E File Offset: 0x00000B0E
		public string Port { get; set; }

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060001F0 RID: 496 RVA: 0x00002917 File Offset: 0x00000B17
		// (set) Token: 0x060001F1 RID: 497 RVA: 0x0000291F File Offset: 0x00000B1F
		public string Time { get; set; }

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x00002928 File Offset: 0x00000B28
		// (set) Token: 0x060001F3 RID: 499 RVA: 0x00002930 File Offset: 0x00000B30
		public string Method { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x00002939 File Offset: 0x00000B39
		// (set) Token: 0x060001F5 RID: 501 RVA: 0x00002941 File Offset: 0x00000B41
		public string Server { get; set; }
	}
}
