﻿using System;

namespace AstroStrike.Modules
{
	// Token: 0x0200005D RID: 93
	public class DiscordModules
	{
		// Token: 0x17000041 RID: 65
		// (get) Token: 0x060001FE RID: 510 RVA: 0x0000297D File Offset: 0x00000B7D
		// (set) Token: 0x060001FF RID: 511 RVA: 0x00002985 File Offset: 0x00000B85
		public bool Error { get; set; }
	}
}
