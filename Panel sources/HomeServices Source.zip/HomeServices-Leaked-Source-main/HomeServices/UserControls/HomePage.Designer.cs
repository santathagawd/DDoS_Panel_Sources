﻿
namespace HomeServices.UserControls
{
    partial class HomePage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.AppVersion = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.totaltools = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.apcountlabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.totaluserslabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ProgressBar = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.LastUpdateLabel = new System.Windows.Forms.Label();
            this.AnnouncementBox = new System.Windows.Forms.RichTextBox();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.label18 = new System.Windows.Forms.Label();
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.planname = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            this.exdate = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.userdetails = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.label10 = new System.Windows.Forms.Label();
            this.welcomelabelk = new System.Windows.Forms.Label();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.WebsiteLinkBTn = new Guna.UI2.WinForms.Guna2Button();
            this.YoutubeBTN = new Guna.UI2.WinForms.Guna2Button();
            this.label19 = new System.Windows.Forms.Label();
            this.InstagramlibkBTN = new Guna.UI2.WinForms.Guna2Button();
            this.DiscordLinkBTn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button14 = new Guna.UI2.WinForms.Guna2Button();
            this.label25 = new System.Windows.Forms.Label();
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel3.SuspendLayout();
            this.guna2Panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(20)))), ((int)(((byte)(166)))));
            this.guna2Panel1.BorderRadius = 5;
            this.guna2Panel1.BorderThickness = 2;
            this.guna2Panel1.Controls.Add(this.guna2Button5);
            this.guna2Panel1.Controls.Add(this.AppVersion);
            this.guna2Panel1.Controls.Add(this.label9);
            this.guna2Panel1.Controls.Add(this.guna2Button4);
            this.guna2Panel1.Controls.Add(this.totaltools);
            this.guna2Panel1.Controls.Add(this.label7);
            this.guna2Panel1.Controls.Add(this.guna2Button3);
            this.guna2Panel1.Controls.Add(this.apcountlabel);
            this.guna2Panel1.Controls.Add(this.label5);
            this.guna2Panel1.Controls.Add(this.guna2Button2);
            this.guna2Panel1.Controls.Add(this.totaluserslabel);
            this.guna2Panel1.Controls.Add(this.label2);
            this.guna2Panel1.Controls.Add(this.ProgressBar);
            this.guna2Panel1.Controls.Add(this.guna2Button1);
            this.guna2Panel1.Controls.Add(this.label1);
            this.guna2Panel1.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2Panel1.Location = new System.Drawing.Point(33, 54);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(468, 147);
            this.guna2Panel1.TabIndex = 0;
            // 
            // guna2Button5
            // 
            this.guna2Button5.BorderRadius = 5;
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button5.Image")));
            this.guna2Button5.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2Button5.Location = new System.Drawing.Point(342, 76);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(32, 32);
            this.guna2Button5.TabIndex = 16;
            // 
            // AppVersion
            // 
            this.AppVersion.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.AppVersion.ForeColor = System.Drawing.Color.Gray;
            this.AppVersion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AppVersion.Location = new System.Drawing.Point(378, 87);
            this.AppVersion.Name = "AppVersion";
            this.AppVersion.Size = new System.Drawing.Size(64, 19);
            this.AppVersion.TabIndex = 15;
            this.AppVersion.Text = "N/A";
            this.AppVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.LightGray;
            this.label9.Location = new System.Drawing.Point(338, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 19);
            this.label9.TabIndex = 14;
            this.label9.Text = "AppVersion:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Button4
            // 
            this.guna2Button4.BorderRadius = 5;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button4.Image")));
            this.guna2Button4.ImageSize = new System.Drawing.Size(33, 33);
            this.guna2Button4.Location = new System.Drawing.Point(235, 76);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(30, 30);
            this.guna2Button4.TabIndex = 12;
            // 
            // totaltools
            // 
            this.totaltools.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.totaltools.ForeColor = System.Drawing.Color.Gray;
            this.totaltools.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.totaltools.Location = new System.Drawing.Point(271, 87);
            this.totaltools.Name = "totaltools";
            this.totaltools.Size = new System.Drawing.Size(64, 19);
            this.totaltools.TabIndex = 11;
            this.totaltools.Text = "N/A";
            this.totaltools.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.LightGray;
            this.label7.Location = new System.Drawing.Point(231, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 19);
            this.label7.TabIndex = 10;
            this.label7.Text = "Total Tools:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Button3
            // 
            this.guna2Button3.BorderRadius = 5;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button3.Image")));
            this.guna2Button3.ImageSize = new System.Drawing.Size(30, 28);
            this.guna2Button3.Location = new System.Drawing.Point(130, 76);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(30, 30);
            this.guna2Button3.TabIndex = 8;
            // 
            // apcountlabel
            // 
            this.apcountlabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.apcountlabel.ForeColor = System.Drawing.Color.Gray;
            this.apcountlabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.apcountlabel.Location = new System.Drawing.Point(168, 87);
            this.apcountlabel.Name = "apcountlabel";
            this.apcountlabel.Size = new System.Drawing.Size(64, 19);
            this.apcountlabel.TabIndex = 7;
            this.apcountlabel.Text = "N/a";
            this.apcountlabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.LightGray;
            this.label5.Location = new System.Drawing.Point(128, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Total APIs:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 5;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button2.Image")));
            this.guna2Button2.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2Button2.Location = new System.Drawing.Point(31, 76);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(30, 30);
            this.guna2Button2.TabIndex = 4;
            // 
            // totaluserslabel
            // 
            this.totaluserslabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.totaluserslabel.ForeColor = System.Drawing.Color.Gray;
            this.totaluserslabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.totaluserslabel.Location = new System.Drawing.Point(67, 87);
            this.totaluserslabel.Name = "totaluserslabel";
            this.totaluserslabel.Size = new System.Drawing.Size(64, 19);
            this.totaluserslabel.TabIndex = 3;
            this.totaluserslabel.Text = "N/A";
            this.totaluserslabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.LightGray;
            this.label2.Location = new System.Drawing.Point(27, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Total Uses:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProgressBar
            // 
            this.ProgressBar.BorderRadius = 1;
            this.ProgressBar.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ProgressBar.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.ProgressBar.Location = new System.Drawing.Point(31, 126);
            this.ProgressBar.Minimum = 60;
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(68)))), ((int)(((byte)(255)))));
            this.ProgressBar.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(48)))), ((int)(((byte)(194)))));
            this.ProgressBar.ShadowDecoration.Parent = this.ProgressBar;
            this.ProgressBar.Size = new System.Drawing.Size(411, 5);
            this.ProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.ProgressBar.TabIndex = 1;
            this.ProgressBar.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.ProgressBar.Value = 60;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 5;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageSize = new System.Drawing.Size(23, 23);
            this.guna2Button1.Location = new System.Drawing.Point(424, 5);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(35, 35);
            this.guna2Button1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(144, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Application Information";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(20)))), ((int)(((byte)(166)))));
            this.guna2Panel2.BorderRadius = 5;
            this.guna2Panel2.BorderThickness = 2;
            this.guna2Panel2.Controls.Add(this.LastUpdateLabel);
            this.guna2Panel2.Controls.Add(this.AnnouncementBox);
            this.guna2Panel2.Controls.Add(this.guna2Button10);
            this.guna2Panel2.Controls.Add(this.label18);
            this.guna2Panel2.Controls.Add(this.guna2Button13);
            this.guna2Panel2.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2Panel2.Location = new System.Drawing.Point(33, 218);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(468, 233);
            this.guna2Panel2.TabIndex = 1;
            // 
            // LastUpdateLabel
            // 
            this.LastUpdateLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.LastUpdateLabel.ForeColor = System.Drawing.Color.DarkGray;
            this.LastUpdateLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LastUpdateLabel.Location = new System.Drawing.Point(50, 200);
            this.LastUpdateLabel.Name = "LastUpdateLabel";
            this.LastUpdateLabel.Size = new System.Drawing.Size(384, 19);
            this.LastUpdateLabel.TabIndex = 4;
            this.LastUpdateLabel.Text = "loading...";
            this.LastUpdateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AnnouncementBox
            // 
            this.AnnouncementBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.AnnouncementBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AnnouncementBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.AnnouncementBox.ForeColor = System.Drawing.Color.Gray;
            this.AnnouncementBox.Location = new System.Drawing.Point(25, 46);
            this.AnnouncementBox.Name = "AnnouncementBox";
            this.AnnouncementBox.ReadOnly = true;
            this.AnnouncementBox.Size = new System.Drawing.Size(417, 149);
            this.AnnouncementBox.TabIndex = 2;
            this.AnnouncementBox.Text = "Loading...";
            // 
            // guna2Button10
            // 
            this.guna2Button10.BorderRadius = 5;
            this.guna2Button10.CheckedState.Parent = this.guna2Button10;
            this.guna2Button10.CustomImages.Parent = this.guna2Button10;
            this.guna2Button10.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button10.ForeColor = System.Drawing.Color.White;
            this.guna2Button10.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button10.HoverState.Parent = this.guna2Button10;
            this.guna2Button10.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button10.Image")));
            this.guna2Button10.ImageSize = new System.Drawing.Size(23, 23);
            this.guna2Button10.Location = new System.Drawing.Point(421, 5);
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.ShadowDecoration.Parent = this.guna2Button10;
            this.guna2Button10.Size = new System.Drawing.Size(35, 35);
            this.guna2Button10.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(147, 11);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(184, 21);
            this.label18.TabIndex = 1;
            this.label18.Text = "Recent Announcement";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Button13
            // 
            this.guna2Button13.BorderRadius = 5;
            this.guna2Button13.CheckedState.Parent = this.guna2Button13;
            this.guna2Button13.CustomImages.Parent = this.guna2Button13;
            this.guna2Button13.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button13.ForeColor = System.Drawing.Color.White;
            this.guna2Button13.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button13.HoverState.Parent = this.guna2Button13;
            this.guna2Button13.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button13.Image")));
            this.guna2Button13.Location = new System.Drawing.Point(22, 194);
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.ShadowDecoration.Parent = this.guna2Button13;
            this.guna2Button13.Size = new System.Drawing.Size(30, 30);
            this.guna2Button13.TabIndex = 17;
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(20)))), ((int)(((byte)(166)))));
            this.guna2Panel3.BorderRadius = 5;
            this.guna2Panel3.BorderThickness = 2;
            this.guna2Panel3.Controls.Add(this.planname);
            this.guna2Panel3.Controls.Add(this.label17);
            this.guna2Panel3.Controls.Add(this.guna2Button9);
            this.guna2Panel3.Controls.Add(this.exdate);
            this.guna2Panel3.Controls.Add(this.label15);
            this.guna2Panel3.Controls.Add(this.guna2Button8);
            this.guna2Panel3.Controls.Add(this.userdetails);
            this.guna2Panel3.Controls.Add(this.label14);
            this.guna2Panel3.Controls.Add(this.guna2Button7);
            this.guna2Panel3.Controls.Add(this.guna2Button6);
            this.guna2Panel3.Controls.Add(this.label10);
            this.guna2Panel3.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2Panel3.Location = new System.Drawing.Point(518, 218);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.Size = new System.Drawing.Size(416, 233);
            this.guna2Panel3.TabIndex = 2;
            // 
            // planname
            // 
            this.planname.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.planname.ForeColor = System.Drawing.Color.Gray;
            this.planname.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.planname.Location = new System.Drawing.Point(62, 185);
            this.planname.Name = "planname";
            this.planname.Size = new System.Drawing.Size(254, 19);
            this.planname.TabIndex = 15;
            this.planname.Text = "N/A";
            this.planname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.LightGray;
            this.label17.Location = new System.Drawing.Point(61, 164);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 19);
            this.label17.TabIndex = 14;
            this.label17.Text = "Plan:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Button9
            // 
            this.guna2Button9.BorderRadius = 5;
            this.guna2Button9.CheckedState.Parent = this.guna2Button9;
            this.guna2Button9.CustomImages.Parent = this.guna2Button9;
            this.guna2Button9.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button9.ForeColor = System.Drawing.Color.White;
            this.guna2Button9.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button9.HoverState.Parent = this.guna2Button9;
            this.guna2Button9.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button9.Image")));
            this.guna2Button9.ImageSize = new System.Drawing.Size(32, 32);
            this.guna2Button9.Location = new System.Drawing.Point(20, 164);
            this.guna2Button9.Name = "guna2Button9";
            this.guna2Button9.ShadowDecoration.Parent = this.guna2Button9;
            this.guna2Button9.Size = new System.Drawing.Size(40, 40);
            this.guna2Button9.TabIndex = 16;
            // 
            // exdate
            // 
            this.exdate.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.exdate.ForeColor = System.Drawing.Color.Gray;
            this.exdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.exdate.Location = new System.Drawing.Point(61, 129);
            this.exdate.Name = "exdate";
            this.exdate.Size = new System.Drawing.Size(254, 19);
            this.exdate.TabIndex = 12;
            this.exdate.Text = "N/A";
            this.exdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.LightGray;
            this.label15.Location = new System.Drawing.Point(60, 108);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 19);
            this.label15.TabIndex = 11;
            this.label15.Text = "Expiry Date:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Button8
            // 
            this.guna2Button8.BorderRadius = 5;
            this.guna2Button8.CheckedState.Parent = this.guna2Button8;
            this.guna2Button8.CustomImages.Parent = this.guna2Button8;
            this.guna2Button8.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button8.ForeColor = System.Drawing.Color.White;
            this.guna2Button8.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button8.HoverState.Parent = this.guna2Button8;
            this.guna2Button8.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button8.Image")));
            this.guna2Button8.ImageSize = new System.Drawing.Size(32, 32);
            this.guna2Button8.Location = new System.Drawing.Point(19, 108);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.ShadowDecoration.Parent = this.guna2Button8;
            this.guna2Button8.Size = new System.Drawing.Size(40, 40);
            this.guna2Button8.TabIndex = 13;
            // 
            // userdetails
            // 
            this.userdetails.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.userdetails.ForeColor = System.Drawing.Color.Gray;
            this.userdetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.userdetails.Location = new System.Drawing.Point(61, 71);
            this.userdetails.Name = "userdetails";
            this.userdetails.Size = new System.Drawing.Size(254, 19);
            this.userdetails.TabIndex = 9;
            this.userdetails.Text = "N/A";
            this.userdetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.LightGray;
            this.label14.Location = new System.Drawing.Point(60, 50);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 19);
            this.label14.TabIndex = 8;
            this.label14.Text = "Username:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderRadius = 5;
            this.guna2Button7.CheckedState.Parent = this.guna2Button7;
            this.guna2Button7.CustomImages.Parent = this.guna2Button7;
            this.guna2Button7.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button7.HoverState.Parent = this.guna2Button7;
            this.guna2Button7.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button7.Image")));
            this.guna2Button7.ImageSize = new System.Drawing.Size(32, 32);
            this.guna2Button7.Location = new System.Drawing.Point(19, 50);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.ShadowDecoration.Parent = this.guna2Button7;
            this.guna2Button7.Size = new System.Drawing.Size(40, 40);
            this.guna2Button7.TabIndex = 10;
            // 
            // guna2Button6
            // 
            this.guna2Button6.BorderRadius = 5;
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button6.Image")));
            this.guna2Button6.ImageSize = new System.Drawing.Size(25, 25);
            this.guna2Button6.Location = new System.Drawing.Point(373, 4);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(35, 35);
            this.guna2Button6.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(149, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(130, 21);
            this.label10.TabIndex = 1;
            this.label10.Text = "Account Details";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // welcomelabelk
            // 
            this.welcomelabelk.AutoSize = true;
            this.welcomelabelk.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.welcomelabelk.ForeColor = System.Drawing.Color.LightGray;
            this.welcomelabelk.Location = new System.Drawing.Point(32, 21);
            this.welcomelabelk.Name = "welcomelabelk";
            this.welcomelabelk.Size = new System.Drawing.Size(259, 20);
            this.welcomelabelk.TabIndex = 3;
            this.welcomelabelk.Text = "Welcome to Home Services, Username";
            this.welcomelabelk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(20)))), ((int)(((byte)(166)))));
            this.guna2Panel4.BorderRadius = 5;
            this.guna2Panel4.BorderThickness = 2;
            this.guna2Panel4.Controls.Add(this.WebsiteLinkBTn);
            this.guna2Panel4.Controls.Add(this.YoutubeBTN);
            this.guna2Panel4.Controls.Add(this.label19);
            this.guna2Panel4.Controls.Add(this.InstagramlibkBTN);
            this.guna2Panel4.Controls.Add(this.DiscordLinkBTn);
            this.guna2Panel4.Controls.Add(this.guna2Button14);
            this.guna2Panel4.Controls.Add(this.label25);
            this.guna2Panel4.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2Panel4.Location = new System.Drawing.Point(515, 54);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.ShadowDecoration.Parent = this.guna2Panel4;
            this.guna2Panel4.Size = new System.Drawing.Size(416, 147);
            this.guna2Panel4.TabIndex = 4;
            // 
            // WebsiteLinkBTn
            // 
            this.WebsiteLinkBTn.Animated = true;
            this.WebsiteLinkBTn.BorderRadius = 5;
            this.WebsiteLinkBTn.CheckedState.Parent = this.WebsiteLinkBTn;
            this.WebsiteLinkBTn.CustomImages.Parent = this.WebsiteLinkBTn;
            this.WebsiteLinkBTn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(18)))), ((int)(((byte)(122)))));
            this.WebsiteLinkBTn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.WebsiteLinkBTn.ForeColor = System.Drawing.Color.White;
            this.WebsiteLinkBTn.HoverState.Parent = this.WebsiteLinkBTn;
            this.WebsiteLinkBTn.Location = new System.Drawing.Point(217, 66);
            this.WebsiteLinkBTn.Name = "WebsiteLinkBTn";
            this.WebsiteLinkBTn.PressedColor = System.Drawing.Color.White;
            this.WebsiteLinkBTn.ShadowDecoration.Parent = this.WebsiteLinkBTn;
            this.WebsiteLinkBTn.Size = new System.Drawing.Size(130, 30);
            this.WebsiteLinkBTn.TabIndex = 9;
            this.WebsiteLinkBTn.Text = "Website";
            this.WebsiteLinkBTn.Click += new System.EventHandler(this.WebsiteLinkBTn_Click);
            // 
            // YoutubeBTN
            // 
            this.YoutubeBTN.Animated = true;
            this.YoutubeBTN.BorderRadius = 5;
            this.YoutubeBTN.CheckedState.Parent = this.YoutubeBTN;
            this.YoutubeBTN.CustomImages.Parent = this.YoutubeBTN;
            this.YoutubeBTN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(18)))), ((int)(((byte)(122)))));
            this.YoutubeBTN.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.YoutubeBTN.ForeColor = System.Drawing.Color.White;
            this.YoutubeBTN.HoverState.Parent = this.YoutubeBTN;
            this.YoutubeBTN.Location = new System.Drawing.Point(71, 66);
            this.YoutubeBTN.Name = "YoutubeBTN";
            this.YoutubeBTN.PressedColor = System.Drawing.Color.White;
            this.YoutubeBTN.ShadowDecoration.Parent = this.YoutubeBTN;
            this.YoutubeBTN.Size = new System.Drawing.Size(130, 30);
            this.YoutubeBTN.TabIndex = 8;
            this.YoutubeBTN.Text = "YouTube";
            this.YoutubeBTN.Click += new System.EventHandler(this.YoutubeBTN_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.LightGray;
            this.label19.Location = new System.Drawing.Point(115, 41);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(195, 15);
            this.label19.TabIndex = 7;
            this.label19.Text = "Our social medias to contact us on";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // InstagramlibkBTN
            // 
            this.InstagramlibkBTN.Animated = true;
            this.InstagramlibkBTN.BorderRadius = 5;
            this.InstagramlibkBTN.CheckedState.Parent = this.InstagramlibkBTN;
            this.InstagramlibkBTN.CustomImages.Parent = this.InstagramlibkBTN;
            this.InstagramlibkBTN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(18)))), ((int)(((byte)(122)))));
            this.InstagramlibkBTN.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.InstagramlibkBTN.ForeColor = System.Drawing.Color.White;
            this.InstagramlibkBTN.HoverState.Parent = this.InstagramlibkBTN;
            this.InstagramlibkBTN.Location = new System.Drawing.Point(217, 102);
            this.InstagramlibkBTN.Name = "InstagramlibkBTN";
            this.InstagramlibkBTN.PressedColor = System.Drawing.Color.White;
            this.InstagramlibkBTN.ShadowDecoration.Parent = this.InstagramlibkBTN;
            this.InstagramlibkBTN.Size = new System.Drawing.Size(130, 30);
            this.InstagramlibkBTN.TabIndex = 3;
            this.InstagramlibkBTN.Text = "Instagram";
            this.InstagramlibkBTN.Click += new System.EventHandler(this.InstagramlibkBTN_Click);
            // 
            // DiscordLinkBTn
            // 
            this.DiscordLinkBTn.Animated = true;
            this.DiscordLinkBTn.BorderRadius = 5;
            this.DiscordLinkBTn.CheckedState.Parent = this.DiscordLinkBTn;
            this.DiscordLinkBTn.CustomImages.Parent = this.DiscordLinkBTn;
            this.DiscordLinkBTn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(18)))), ((int)(((byte)(122)))));
            this.DiscordLinkBTn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.DiscordLinkBTn.ForeColor = System.Drawing.Color.White;
            this.DiscordLinkBTn.HoverState.Parent = this.DiscordLinkBTn;
            this.DiscordLinkBTn.Location = new System.Drawing.Point(71, 102);
            this.DiscordLinkBTn.Name = "DiscordLinkBTn";
            this.DiscordLinkBTn.PressedColor = System.Drawing.Color.White;
            this.DiscordLinkBTn.ShadowDecoration.Parent = this.DiscordLinkBTn;
            this.DiscordLinkBTn.Size = new System.Drawing.Size(130, 30);
            this.DiscordLinkBTn.TabIndex = 2;
            this.DiscordLinkBTn.Text = "Discord";
            this.DiscordLinkBTn.Click += new System.EventHandler(this.DiscordLinkBTn_Click);
            // 
            // guna2Button14
            // 
            this.guna2Button14.BorderRadius = 5;
            this.guna2Button14.CheckedState.Parent = this.guna2Button14;
            this.guna2Button14.CustomImages.Parent = this.guna2Button14;
            this.guna2Button14.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button14.ForeColor = System.Drawing.Color.White;
            this.guna2Button14.HoverState.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button14.HoverState.Parent = this.guna2Button14;
            this.guna2Button14.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button14.Image")));
            this.guna2Button14.ImageSize = new System.Drawing.Size(25, 25);
            this.guna2Button14.Location = new System.Drawing.Point(371, 5);
            this.guna2Button14.Name = "guna2Button14";
            this.guna2Button14.ShadowDecoration.Parent = this.guna2Button14;
            this.guna2Button14.Size = new System.Drawing.Size(35, 35);
            this.guna2Button14.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(153, 11);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 21);
            this.label25.TabIndex = 1;
            this.label25.Text = "Stay In Contact";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.Controls.Add(this.guna2Panel4);
            this.Controls.Add(this.welcomelabelk);
            this.Controls.Add(this.guna2Panel3);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "HomePage";
            this.Size = new System.Drawing.Size(968, 482);
            this.Load += new System.EventHandler(this.HomePage_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            this.guna2Panel3.ResumeLayout(false);
            this.guna2Panel3.PerformLayout();
            this.guna2Panel4.ResumeLayout(false);
            this.guna2Panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.Label totaluserslabel;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2ProgressBar ProgressBar;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private System.Windows.Forms.Label AppVersion;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private System.Windows.Forms.Label totaltools;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private System.Windows.Forms.Label apcountlabel;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.RichTextBox AnnouncementBox;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private System.Windows.Forms.Label label18;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label welcomelabelk;
        private System.Windows.Forms.Label userdetails;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label planname;
        private System.Windows.Forms.Label label17;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
        private System.Windows.Forms.Label exdate;
        private System.Windows.Forms.Label label15;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2Button guna2Button14;
        private System.Windows.Forms.Label label25;
        private Guna.UI2.WinForms.Guna2Button DiscordLinkBTn;
        private System.Windows.Forms.Label label19;
        private Guna.UI2.WinForms.Guna2Button InstagramlibkBTN;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2Button WebsiteLinkBTn;
        private Guna.UI2.WinForms.Guna2Button YoutubeBTN;
        private System.Windows.Forms.Label LastUpdateLabel;
    }
}
