﻿namespace Multi_Panel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.TabPanel = new MetroFramework.Controls.MetroTabPage();
            this.errorHandler = new MetroFramework.Controls.MetroLabel();
            this.MethodBox = new MetroFramework.Controls.MetroComboBox();
            this.TimeBox = new MetroFramework.Controls.MetroTextBox();
            this.PortBox = new MetroFramework.Controls.MetroTextBox();
            this.IPBox = new MetroFramework.Controls.MetroTextBox();
            this.stopStressBtn = new MetroFramework.Controls.MetroButton();
            this.stressBtn = new MetroFramework.Controls.MetroButton();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.orgTxt = new MetroFramework.Controls.MetroLabel();
            this.hostnameTxt = new MetroFramework.Controls.MetroLabel();
            this.regionTxt = new MetroFramework.Controls.MetroLabel();
            this.ipTxt = new MetroFramework.Controls.MetroLabel();
            this.countryTxt = new MetroFramework.Controls.MetroLabel();
            this.resolve = new MetroFramework.Controls.MetroButton();
            this.typeresolver = new MetroFramework.Controls.MetroComboBox();
            this.targetResolver = new MetroFramework.Controls.MetroTextBox();
            this.DeveloperLove = new MetroFramework.Controls.MetroLabel();
            this.extIP = new MetroFramework.Controls.MetroLabel();
            this.intIP = new MetroFramework.Controls.MetroLabel();
            this.metroTabControl1.SuspendLayout();
            this.TabPanel.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.TabPanel);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Location = new System.Drawing.Point(12, 64);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(360, 351);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabControl1.UseSelectable = true;
            this.metroTabControl1.UseStyleColors = true;
            // 
            // TabPanel
            // 
            this.TabPanel.Controls.Add(this.errorHandler);
            this.TabPanel.Controls.Add(this.MethodBox);
            this.TabPanel.Controls.Add(this.TimeBox);
            this.TabPanel.Controls.Add(this.PortBox);
            this.TabPanel.Controls.Add(this.IPBox);
            this.TabPanel.Controls.Add(this.stopStressBtn);
            this.TabPanel.Controls.Add(this.stressBtn);
            this.TabPanel.HorizontalScrollbarBarColor = true;
            this.TabPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.TabPanel.HorizontalScrollbarSize = 10;
            this.TabPanel.Location = new System.Drawing.Point(4, 38);
            this.TabPanel.Name = "TabPanel";
            this.TabPanel.Size = new System.Drawing.Size(352, 309);
            this.TabPanel.Style = MetroFramework.MetroColorStyle.Orange;
            this.TabPanel.TabIndex = 0;
            this.TabPanel.Text = "Hub";
            this.TabPanel.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.TabPanel.UseStyleColors = true;
            this.TabPanel.VerticalScrollbarBarColor = true;
            this.TabPanel.VerticalScrollbarHighlightOnWheel = false;
            this.TabPanel.VerticalScrollbarSize = 10;
            // 
            // errorHandler
            // 
            this.errorHandler.AutoSize = true;
            this.errorHandler.Location = new System.Drawing.Point(13, 174);
            this.errorHandler.Name = "errorHandler";
            this.errorHandler.Size = new System.Drawing.Size(0, 0);
            this.errorHandler.Style = MetroFramework.MetroColorStyle.Orange;
            this.errorHandler.TabIndex = 8;
            this.errorHandler.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.errorHandler.UseStyleColors = true;
            // 
            // MethodBox
            // 
            this.MethodBox.DisplayMember = "test";
            this.MethodBox.FormattingEnabled = true;
            this.MethodBox.ItemHeight = 23;
            this.MethodBox.Items.AddRange(new object[] {
            "UDP",
            "STD",
            "TCP"});
            this.MethodBox.Location = new System.Drawing.Point(13, 142);
            this.MethodBox.Name = "MethodBox";
            this.MethodBox.Size = new System.Drawing.Size(334, 29);
            this.MethodBox.Style = MetroFramework.MetroColorStyle.Orange;
            this.MethodBox.TabIndex = 7;
            this.MethodBox.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.MethodBox.UseSelectable = true;
            this.MethodBox.UseStyleColors = true;
            // 
            // TimeBox
            // 
            // 
            // 
            // 
            this.TimeBox.CustomButton.Image = null;
            this.TimeBox.CustomButton.Location = new System.Drawing.Point(300, 1);
            this.TimeBox.CustomButton.Name = "";
            this.TimeBox.CustomButton.Size = new System.Drawing.Size(33, 33);
            this.TimeBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TimeBox.CustomButton.TabIndex = 1;
            this.TimeBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TimeBox.CustomButton.UseSelectable = true;
            this.TimeBox.CustomButton.Visible = false;
            this.TimeBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.TimeBox.Lines = new string[] {
        "60"};
            this.TimeBox.Location = new System.Drawing.Point(13, 101);
            this.TimeBox.MaxLength = 32767;
            this.TimeBox.Multiline = true;
            this.TimeBox.Name = "TimeBox";
            this.TimeBox.PasswordChar = '\0';
            this.TimeBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TimeBox.SelectedText = "";
            this.TimeBox.SelectionLength = 0;
            this.TimeBox.SelectionStart = 0;
            this.TimeBox.ShortcutsEnabled = true;
            this.TimeBox.Size = new System.Drawing.Size(334, 35);
            this.TimeBox.Style = MetroFramework.MetroColorStyle.Orange;
            this.TimeBox.TabIndex = 6;
            this.TimeBox.Text = "60";
            this.TimeBox.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.TimeBox.UseSelectable = true;
            this.TimeBox.UseStyleColors = true;
            this.TimeBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TimeBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.TimeBox.Click += new System.EventHandler(this.TimeBox_Click);
            // 
            // PortBox
            // 
            // 
            // 
            // 
            this.PortBox.CustomButton.Image = null;
            this.PortBox.CustomButton.Location = new System.Drawing.Point(300, 1);
            this.PortBox.CustomButton.Name = "";
            this.PortBox.CustomButton.Size = new System.Drawing.Size(33, 33);
            this.PortBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.PortBox.CustomButton.TabIndex = 1;
            this.PortBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.PortBox.CustomButton.UseSelectable = true;
            this.PortBox.CustomButton.Visible = false;
            this.PortBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.PortBox.Lines = new string[] {
        "80"};
            this.PortBox.Location = new System.Drawing.Point(13, 60);
            this.PortBox.MaxLength = 32767;
            this.PortBox.Multiline = true;
            this.PortBox.Name = "PortBox";
            this.PortBox.PasswordChar = '\0';
            this.PortBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.PortBox.SelectedText = "";
            this.PortBox.SelectionLength = 0;
            this.PortBox.SelectionStart = 0;
            this.PortBox.ShortcutsEnabled = true;
            this.PortBox.Size = new System.Drawing.Size(334, 35);
            this.PortBox.Style = MetroFramework.MetroColorStyle.Orange;
            this.PortBox.TabIndex = 5;
            this.PortBox.Text = "80";
            this.PortBox.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.PortBox.UseSelectable = true;
            this.PortBox.UseStyleColors = true;
            this.PortBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.PortBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.PortBox.Click += new System.EventHandler(this.PortBox_Click);
            // 
            // IPBox
            // 
            // 
            // 
            // 
            this.IPBox.CustomButton.Image = null;
            this.IPBox.CustomButton.Location = new System.Drawing.Point(300, 1);
            this.IPBox.CustomButton.Name = "";
            this.IPBox.CustomButton.Size = new System.Drawing.Size(33, 33);
            this.IPBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.IPBox.CustomButton.TabIndex = 1;
            this.IPBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.IPBox.CustomButton.UseSelectable = true;
            this.IPBox.CustomButton.Visible = false;
            this.IPBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.IPBox.Lines = new string[] {
        "127.0.0.1"};
            this.IPBox.Location = new System.Drawing.Point(13, 19);
            this.IPBox.MaxLength = 32767;
            this.IPBox.Multiline = true;
            this.IPBox.Name = "IPBox";
            this.IPBox.PasswordChar = '\0';
            this.IPBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.IPBox.SelectedText = "";
            this.IPBox.SelectionLength = 0;
            this.IPBox.SelectionStart = 0;
            this.IPBox.ShortcutsEnabled = true;
            this.IPBox.Size = new System.Drawing.Size(334, 35);
            this.IPBox.Style = MetroFramework.MetroColorStyle.Orange;
            this.IPBox.TabIndex = 4;
            this.IPBox.Text = "127.0.0.1";
            this.IPBox.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.IPBox.UseSelectable = true;
            this.IPBox.UseStyleColors = true;
            this.IPBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.IPBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.IPBox.Click += new System.EventHandler(this.IPBox_Click);
            // 
            // stopStressBtn
            // 
            this.stopStressBtn.Location = new System.Drawing.Point(13, 252);
            this.stopStressBtn.Name = "stopStressBtn";
            this.stopStressBtn.Size = new System.Drawing.Size(334, 51);
            this.stopStressBtn.Style = MetroFramework.MetroColorStyle.Orange;
            this.stopStressBtn.TabIndex = 3;
            this.stopStressBtn.Text = "Stop!";
            this.stopStressBtn.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.stopStressBtn.UseSelectable = true;
            this.stopStressBtn.UseStyleColors = true;
            this.stopStressBtn.Click += new System.EventHandler(this.stopStressBtn_Click);
            // 
            // stressBtn
            // 
            this.stressBtn.Location = new System.Drawing.Point(13, 196);
            this.stressBtn.Name = "stressBtn";
            this.stressBtn.Size = new System.Drawing.Size(334, 51);
            this.stressBtn.Style = MetroFramework.MetroColorStyle.Orange;
            this.stressBtn.TabIndex = 2;
            this.stressBtn.Text = "Stress!";
            this.stressBtn.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.stressBtn.UseSelectable = true;
            this.stressBtn.UseStyleColors = true;
            this.stressBtn.Click += new System.EventHandler(this.stressBtn_Click);
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.orgTxt);
            this.metroTabPage2.Controls.Add(this.hostnameTxt);
            this.metroTabPage2.Controls.Add(this.regionTxt);
            this.metroTabPage2.Controls.Add(this.ipTxt);
            this.metroTabPage2.Controls.Add(this.countryTxt);
            this.metroTabPage2.Controls.Add(this.resolve);
            this.metroTabPage2.Controls.Add(this.typeresolver);
            this.metroTabPage2.Controls.Add(this.targetResolver);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(352, 309);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Resolvers";
            this.metroTabPage2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // orgTxt
            // 
            this.orgTxt.AutoSize = true;
            this.orgTxt.Location = new System.Drawing.Point(21, 213);
            this.orgTxt.Name = "orgTxt";
            this.orgTxt.Size = new System.Drawing.Size(92, 19);
            this.orgTxt.Style = MetroFramework.MetroColorStyle.Orange;
            this.orgTxt.TabIndex = 17;
            this.orgTxt.Text = "Organization :";
            this.orgTxt.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.orgTxt.UseStyleColors = true;
            // 
            // hostnameTxt
            // 
            this.hostnameTxt.AutoSize = true;
            this.hostnameTxt.Location = new System.Drawing.Point(24, 271);
            this.hostnameTxt.Name = "hostnameTxt";
            this.hostnameTxt.Size = new System.Drawing.Size(79, 19);
            this.hostnameTxt.Style = MetroFramework.MetroColorStyle.Orange;
            this.hostnameTxt.TabIndex = 16;
            this.hostnameTxt.Text = "Hostname : ";
            this.hostnameTxt.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.hostnameTxt.UseStyleColors = true;
            // 
            // regionTxt
            // 
            this.regionTxt.AutoSize = true;
            this.regionTxt.Location = new System.Drawing.Point(22, 241);
            this.regionTxt.Name = "regionTxt";
            this.regionTxt.Size = new System.Drawing.Size(61, 19);
            this.regionTxt.Style = MetroFramework.MetroColorStyle.Orange;
            this.regionTxt.TabIndex = 15;
            this.regionTxt.Text = "Region : ";
            this.regionTxt.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.regionTxt.UseStyleColors = true;
            // 
            // ipTxt
            // 
            this.ipTxt.AutoSize = true;
            this.ipTxt.Location = new System.Drawing.Point(21, 160);
            this.ipTxt.Name = "ipTxt";
            this.ipTxt.Size = new System.Drawing.Size(27, 19);
            this.ipTxt.Style = MetroFramework.MetroColorStyle.Orange;
            this.ipTxt.TabIndex = 13;
            this.ipTxt.Text = "IP :";
            this.ipTxt.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.ipTxt.UseStyleColors = true;
            // 
            // countryTxt
            // 
            this.countryTxt.AutoSize = true;
            this.countryTxt.Location = new System.Drawing.Point(22, 185);
            this.countryTxt.Name = "countryTxt";
            this.countryTxt.Size = new System.Drawing.Size(63, 19);
            this.countryTxt.Style = MetroFramework.MetroColorStyle.Orange;
            this.countryTxt.TabIndex = 1;
            this.countryTxt.Text = "Country :";
            this.countryTxt.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.countryTxt.UseStyleColors = true;
            // 
            // resolve
            // 
            this.resolve.Location = new System.Drawing.Point(3, 96);
            this.resolve.Name = "resolve";
            this.resolve.Size = new System.Drawing.Size(334, 51);
            this.resolve.Style = MetroFramework.MetroColorStyle.Orange;
            this.resolve.TabIndex = 12;
            this.resolve.Text = "Resolve!";
            this.resolve.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.resolve.UseSelectable = true;
            this.resolve.UseStyleColors = true;
            this.resolve.Click += new System.EventHandler(this.resolve_Click);
            // 
            // typeresolver
            // 
            this.typeresolver.DisplayMember = "test";
            this.typeresolver.FormattingEnabled = true;
            this.typeresolver.ItemHeight = 23;
            this.typeresolver.Items.AddRange(new object[] {
            "Geo Locator",
            "Pinger",
            "Host2IP"});
            this.typeresolver.Location = new System.Drawing.Point(3, 61);
            this.typeresolver.Name = "typeresolver";
            this.typeresolver.Size = new System.Drawing.Size(334, 29);
            this.typeresolver.Style = MetroFramework.MetroColorStyle.Orange;
            this.typeresolver.TabIndex = 11;
            this.typeresolver.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.typeresolver.UseSelectable = true;
            this.typeresolver.UseStyleColors = true;
            // 
            // targetResolver
            // 
            // 
            // 
            // 
            this.targetResolver.CustomButton.Image = null;
            this.targetResolver.CustomButton.Location = new System.Drawing.Point(300, 1);
            this.targetResolver.CustomButton.Name = "";
            this.targetResolver.CustomButton.Size = new System.Drawing.Size(33, 33);
            this.targetResolver.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.targetResolver.CustomButton.TabIndex = 1;
            this.targetResolver.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.targetResolver.CustomButton.UseSelectable = true;
            this.targetResolver.CustomButton.Visible = false;
            this.targetResolver.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.targetResolver.Lines = new string[] {
        "147.135.121.66"};
            this.targetResolver.Location = new System.Drawing.Point(3, 20);
            this.targetResolver.MaxLength = 32767;
            this.targetResolver.Multiline = true;
            this.targetResolver.Name = "targetResolver";
            this.targetResolver.PasswordChar = '\0';
            this.targetResolver.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.targetResolver.SelectedText = "";
            this.targetResolver.SelectionLength = 0;
            this.targetResolver.SelectionStart = 0;
            this.targetResolver.ShortcutsEnabled = true;
            this.targetResolver.Size = new System.Drawing.Size(334, 35);
            this.targetResolver.Style = MetroFramework.MetroColorStyle.Orange;
            this.targetResolver.TabIndex = 8;
            this.targetResolver.Text = "147.135.121.66";
            this.targetResolver.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.targetResolver.UseSelectable = true;
            this.targetResolver.UseStyleColors = true;
            this.targetResolver.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.targetResolver.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // DeveloperLove
            // 
            this.DeveloperLove.AutoSize = true;
            this.DeveloperLove.Location = new System.Drawing.Point(210, 22);
            this.DeveloperLove.Name = "DeveloperLove";
            this.DeveloperLove.Size = new System.Drawing.Size(162, 19);
            this.DeveloperLove.Style = MetroFramework.MetroColorStyle.Orange;
            this.DeveloperLove.TabIndex = 18;
            this.DeveloperLove.Text = "By DevilsExploits with Love";
            this.DeveloperLove.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.DeveloperLove.UseStyleColors = true;
            // 
            // extIP
            // 
            this.extIP.AutoSize = true;
            this.extIP.Location = new System.Drawing.Point(12, 414);
            this.extIP.Name = "extIP";
            this.extIP.Size = new System.Drawing.Size(81, 19);
            this.extIP.Style = MetroFramework.MetroColorStyle.Orange;
            this.extIP.TabIndex = 19;
            this.extIP.Text = "Exteranl IP : ";
            this.extIP.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.extIP.UseStyleColors = true;
            // 
            // intIP
            // 
            this.intIP.AutoSize = true;
            this.intIP.Location = new System.Drawing.Point(181, 414);
            this.intIP.Name = "intIP";
            this.intIP.Size = new System.Drawing.Size(78, 19);
            this.intIP.Style = MetroFramework.MetroColorStyle.Orange;
            this.intIP.TabIndex = 21;
            this.intIP.Text = "Internal IP : ";
            this.intIP.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.intIP.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.intIP.UseStyleColors = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 438);
            this.Controls.Add(this.intIP);
            this.Controls.Add(this.extIP);
            this.Controls.Add(this.DeveloperLove);
            this.Controls.Add(this.metroTabControl1);
            this.Name = "Form1";
            this.Style = MetroFramework.MetroColorStyle.Orange;
            this.Text = "Easy Panel";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabControl1.ResumeLayout(false);
            this.TabPanel.ResumeLayout(false);
            this.TabPanel.PerformLayout();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage TabPanel;
        private MetroFramework.Controls.MetroComboBox MethodBox;
        private MetroFramework.Controls.MetroTextBox TimeBox;
        private MetroFramework.Controls.MetroTextBox PortBox;
        private MetroFramework.Controls.MetroTextBox IPBox;
        private MetroFramework.Controls.MetroButton stopStressBtn;
        private MetroFramework.Controls.MetroButton stressBtn;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroLabel errorHandler;
        private MetroFramework.Controls.MetroButton resolve;
        private MetroFramework.Controls.MetroComboBox typeresolver;
        private MetroFramework.Controls.MetroTextBox targetResolver;
        private MetroFramework.Controls.MetroLabel ipTxt;
        private MetroFramework.Controls.MetroLabel countryTxt;
        private MetroFramework.Controls.MetroLabel regionTxt;
        private MetroFramework.Controls.MetroLabel hostnameTxt;
        private MetroFramework.Controls.MetroLabel orgTxt;
        private MetroFramework.Controls.MetroLabel DeveloperLove;
        private MetroFramework.Controls.MetroLabel extIP;
        private MetroFramework.Controls.MetroLabel intIP;
    }
}

