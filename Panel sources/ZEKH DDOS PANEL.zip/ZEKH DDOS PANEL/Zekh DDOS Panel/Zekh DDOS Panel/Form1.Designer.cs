﻿namespace Zekh_DDOS_Panel
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.thirteenForm1 = new Teen.ThirteenForm();
            this.thirteenTextBox1 = new Teen.ThirteenTextBox();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.thirteenTextBox2 = new Teen.ThirteenTextBox();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.thirteenTextBox3 = new Teen.ThirteenTextBox();
            this.gunaGradientButton1 = new Guna.UI.WinForms.GunaGradientButton();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.thirteenControlBox1 = new Teen.ThirteenControlBox();
            this.thirteenForm1.SuspendLayout();
            this.SuspendLayout();
            // 
            // thirteenForm1
            // 
            this.thirteenForm1.AccentColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.thirteenForm1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.thirteenForm1.ColorScheme = Teen.ThirteenForm.ColorSchemes.Dark;
            this.thirteenForm1.Controls.Add(this.thirteenControlBox1);
            this.thirteenForm1.Controls.Add(this.gunaLabel4);
            this.thirteenForm1.Controls.Add(this.gunaGradientButton1);
            this.thirteenForm1.Controls.Add(this.gunaLabel3);
            this.thirteenForm1.Controls.Add(this.thirteenTextBox3);
            this.thirteenForm1.Controls.Add(this.gunaLabel2);
            this.thirteenForm1.Controls.Add(this.thirteenTextBox2);
            this.thirteenForm1.Controls.Add(this.gunaLabel1);
            this.thirteenForm1.Controls.Add(this.thirteenTextBox1);
            this.thirteenForm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.thirteenForm1.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F);
            this.thirteenForm1.ForeColor = System.Drawing.Color.White;
            this.thirteenForm1.Location = new System.Drawing.Point(0, 0);
            this.thirteenForm1.Name = "thirteenForm1";
            this.thirteenForm1.Size = new System.Drawing.Size(282, 374);
            this.thirteenForm1.TabIndex = 0;
            this.thirteenForm1.Text = "Zekh DDOS Panel";
            // 
            // thirteenTextBox1
            // 
            this.thirteenTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.thirteenTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thirteenTextBox1.ColorScheme = Teen.ThirteenTextBox.ColorSchemes.Dark;
            this.thirteenTextBox1.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F);
            this.thirteenTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.thirteenTextBox1.Location = new System.Drawing.Point(27, 85);
            this.thirteenTextBox1.Name = "thirteenTextBox1";
            this.thirteenTextBox1.Size = new System.Drawing.Size(228, 25);
            this.thirteenTextBox1.TabIndex = 0;
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.gunaLabel1.Location = new System.Drawing.Point(27, 60);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(45, 20);
            this.gunaLabel1.TabIndex = 1;
            this.gunaLabel1.Text = "User :";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.gunaLabel2.Location = new System.Drawing.Point(27, 128);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(77, 20);
            this.gunaLabel2.TabIndex = 3;
            this.gunaLabel2.Text = "Password :";
            // 
            // thirteenTextBox2
            // 
            this.thirteenTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.thirteenTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thirteenTextBox2.ColorScheme = Teen.ThirteenTextBox.ColorSchemes.Dark;
            this.thirteenTextBox2.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F);
            this.thirteenTextBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.thirteenTextBox2.Location = new System.Drawing.Point(27, 153);
            this.thirteenTextBox2.Name = "thirteenTextBox2";
            this.thirteenTextBox2.Size = new System.Drawing.Size(228, 25);
            this.thirteenTextBox2.TabIndex = 2;
            this.thirteenTextBox2.UseSystemPasswordChar = true;
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.gunaLabel3.Location = new System.Drawing.Point(27, 196);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(55, 20);
            this.gunaLabel3.TabIndex = 5;
            this.gunaLabel3.Text = "Token :";
            // 
            // thirteenTextBox3
            // 
            this.thirteenTextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.thirteenTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thirteenTextBox3.ColorScheme = Teen.ThirteenTextBox.ColorSchemes.Dark;
            this.thirteenTextBox3.Font = new System.Drawing.Font("Segoe UI Semilight", 9.75F);
            this.thirteenTextBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.thirteenTextBox3.Location = new System.Drawing.Point(27, 221);
            this.thirteenTextBox3.Name = "thirteenTextBox3";
            this.thirteenTextBox3.Size = new System.Drawing.Size(228, 25);
            this.thirteenTextBox3.TabIndex = 4;
            // 
            // gunaGradientButton1
            // 
            this.gunaGradientButton1.AnimationHoverSpeed = 0.07F;
            this.gunaGradientButton1.AnimationSpeed = 0.03F;
            this.gunaGradientButton1.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.gunaGradientButton1.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.gunaGradientButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientButton1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaGradientButton1.ForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.Image = ((System.Drawing.Image)(resources.GetObject("gunaGradientButton1.Image")));
            this.gunaGradientButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaGradientButton1.Location = new System.Drawing.Point(27, 269);
            this.gunaGradientButton1.Name = "gunaGradientButton1";
            this.gunaGradientButton1.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.gunaGradientButton1.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.gunaGradientButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverImage = null;
            this.gunaGradientButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.Size = new System.Drawing.Size(228, 42);
            this.gunaGradientButton1.TabIndex = 6;
            this.gunaGradientButton1.Text = "Login";
            this.gunaGradientButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton1.Click += new System.EventHandler(this.gunaGradientButton1_Click);
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.gunaLabel4.Location = new System.Drawing.Point(6, 353);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(93, 15);
            this.gunaLabel4.TabIndex = 7;
            this.gunaLabel4.Text = "cracked.to/Zekh";
            // 
            // thirteenControlBox1
            // 
            this.thirteenControlBox1.AccentColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.thirteenControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.thirteenControlBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.thirteenControlBox1.ColorScheme = Teen.ThirteenControlBox.ColorSchemes.Dark;
            this.thirteenControlBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.thirteenControlBox1.Location = new System.Drawing.Point(179, 3);
            this.thirteenControlBox1.Name = "thirteenControlBox1";
            this.thirteenControlBox1.Size = new System.Drawing.Size(100, 25);
            this.thirteenControlBox1.TabIndex = 8;
            this.thirteenControlBox1.Text = "thirteenControlBox1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 374);
            this.Controls.Add(this.thirteenForm1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.thirteenForm1.ResumeLayout(false);
            this.thirteenForm1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Teen.ThirteenForm thirteenForm1;
        private Guna.UI.WinForms.GunaGradientButton gunaGradientButton1;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Teen.ThirteenTextBox thirteenTextBox3;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Teen.ThirteenTextBox thirteenTextBox2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Teen.ThirteenTextBox thirteenTextBox1;
        private Teen.ThirteenControlBox thirteenControlBox1;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
    }
}

