﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zekh_DDOS_Panel
    // Open Source DDOS Panel by Zekh from cracked.to
    // cracked.to/Zekh
{
    public partial class Form2 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        WebClient ZekhDDOSPanel = new WebClient();
        public Form2()
        {
            InitializeComponent();
        }

        private void gunaElipsePanel3_Paint(object sender, PaintEventArgs e)
        {
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void siticoneRoundedGradientButton1_Click(object sender, EventArgs e)
        {
            // Open Source DDOS Panel by Zekh from cracked.to
            // cracked.to/Zekh
            WebClient Zekh = new WebClient();
            MessageBox.Show("\r\nIP:" + labelhost.Text + "\r\nPort:" + labelport.Text + "\r\nTime:" + labeltime.Text + "\r\nMethod:" + siticoneRoundedComboBox1.Text, "Attack Sent");
            labelhost.Enabled = false;
            labelport.Enabled = false;
            labeltime.Enabled = false;
            siticoneRoundedComboBox1.Enabled = false;
            siticoneRoundedGradientButton1.Enabled = false;
            timer1.Interval = 10000; // here time in milliseconds
            timer1.Start();
        }

        private void siticoneRoundedGradientButton2_Click(object sender, EventArgs e)
        {
            // Open Source DDOS Panel by Zekh from cracked.to
            // cracked.to/Zekh
            WebClient Zekh = new WebClient();
            MessageBox.Show("\r\nIP:" + labelhost.Text + "\r\nPort:" + labelport.Text + "\r\nTime:" + labeltime.Text + "\r\nMethod:" + siticoneRoundedComboBox1.Text, "Attack Stop");
            labelhost.Enabled = true;
            labelport.Enabled = true;
            labeltime.Enabled = true;
            siticoneRoundedComboBox1.Enabled = true;
            siticoneRoundedGradientButton1.Enabled = true;
        }

        private void gunaGradientButton1_Click(object sender, EventArgs e)
        {
            // Open Source DDOS Panel by Zekh from cracked.to
            // cracked.to/Zekh
            MessageBox.Show(new WebClient().DownloadString("http://api.c99.nl/portscanner?key=luis43fw.politofr21f97@gmail.com&host=" + this.labelhost.Text));
        }

        private void gunaGradientButton2_Click(object sender, EventArgs e)
        {
            // Open Source DDOS Panel by Zekh from cracked.to
            // cracked.to/Zekh
            MessageBox.Show(new WebClient().DownloadString("http://api.c99.nl/geoip?key=luis43fw.politofr21f97@gmail.com&host=" + this.labelhost.Text));
        }

        private void gunaGradientButton3_Click(object sender, EventArgs e)
        {
            // Open Source DDOS Panel by Zekh from cracked.to
            // cracked.to/Zekh
            MessageBox.Show(new WebClient().DownloadString("http://api.c99.nl/nmap?key=luis43fw.politofr21f97@gmail.com&host=" + this.labelhost.Text));
        }

        private void gunaGradientButton4_Click(object sender, EventArgs e)
        {
            // Open Source DDOS Panel by Zekh from cracked.to
            // cracked.to/Zekh
            System.Diagnostics.ProcessStartInfo proc = new System.Diagnostics.ProcessStartInfo();
            proc.FileName = @"C:\windows\system32\cmd.exe";
            proc.Arguments = "/c ping  " + labelhost.Text + " ";
            System.Diagnostics.Process.Start(proc);
            labelhost.Focus();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void gunaElipsePanel1_MouseMove(object sender, MouseEventArgs e)
        {
            Move_Form(Handle, e);
        }

        public void Move_Form(IntPtr Handle, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}
