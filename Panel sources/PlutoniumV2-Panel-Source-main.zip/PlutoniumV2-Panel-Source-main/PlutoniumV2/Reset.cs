﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using SafeGuard;

// Token: 0x02000015 RID: 21
public partial class Reset : Form
{
	// Token: 0x060000A0 RID: 160 RVA: 0x000024DC File Offset: 0x000006DC
	public Reset()
	{
		this.InitializeComponent();
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00007978 File Offset: 0x00005B78
	private void ResetBtn_Click(object sender, EventArgs e)
	{
		ErrorResponse errorResponse = ClientFunctions.ResetPassword(this.usernameTB.Text, Class4.string_0, this.passTB.Text, this.tokenTB.Text);
		if (errorResponse.Failure)
		{
			MessageBox.Show(errorResponse.Message, Class5.string_0);
		}
		else
		{
			MessageBox.Show(errorResponse.Message, Class5.string_0);
			Class3.loginResponse_0 = ClientFunctions.Login(this.usernameTB.Text, this.passTB.Text, Class4.string_0);
			if (Class3.loginResponse_0.Failure)
			{
				MessageBox.Show(Class3.loginResponse_0.Message, Class5.string_0);
			}
			else
			{
				Class3.string_0 = this.passTB.Text;
				MessageBox.Show(Class3.loginResponse_0.Message, Class5.string_0);
				base.Hide();
				Main main = new Main();
				main.ShowDialog();
				base.Close();
			}
		}
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00002050 File Offset: 0x00000250
	private void panel1_Paint(object sender, PaintEventArgs e)
	{
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x0000247D File Offset: 0x0000067D
	private void label7_Click(object sender, EventArgs e)
	{
		base.WindowState = FormWindowState.Minimized;
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x00002205 File Offset: 0x00000405
	private void label6_Click(object sender, EventArgs e)
	{
		Environment.Exit(0);
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x000024F1 File Offset: 0x000006F1
	private void button1_Click(object sender, EventArgs e)
	{
		base.Hide();
		new Main().ShowDialog();
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x00007A68 File Offset: 0x00005C68
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000097 RID: 151
	private IContainer icontainer_0 = null;
}
