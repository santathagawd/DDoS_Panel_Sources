﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using SafeGuard;

// Token: 0x02000004 RID: 4
internal static class Class0
{
	// Token: 0x0600001E RID: 30 RVA: 0x00002534 File Offset: 0x00000734
	public static List<GClass0> smethod_0()
	{
		try
		{
			Class0.list_0 = JsonConvert.DeserializeObject<List<GClass0>>(Tools.getRequest("https://safeguardauth.us/GetOnGoingAttacks?programid=" + Class4.string_0 + "&username=" + Class3.loginResponse_0.UserName));
		}
		catch
		{
			Class0.list_0 = new List<GClass0>();
		}
		return Class0.list_0;
	}

	// Token: 0x0600001F RID: 31 RVA: 0x00002598 File Offset: 0x00000798
	public static List<GClass0> smethod_1(int int_0)
	{
		try
		{
			Class0.list_1 = JsonConvert.DeserializeObject<List<GClass0>>(Tools.getRequest(string.Format("https://safeguardauth.us/GetPassedAttacks?programid={0}&username={1}&num={2}", Class4.string_0, Class3.loginResponse_0.UserName, int_0)));
		}
		catch
		{
			Class0.list_1 = new List<GClass0>();
		}
		return Class0.list_1;
	}

	// Token: 0x06000020 RID: 32 RVA: 0x000025FC File Offset: 0x000007FC
	public static List<GClass1> smethod_2()
	{
		try
		{
			Class0.list_2 = JsonConvert.DeserializeObject<List<GClass1>>(Tools.getRequest("https://safeguardauth.us/GetMethodStats?programid=" + Class4.string_0 + "&username=" + Class3.loginResponse_0.UserName));
		}
		catch
		{
			Class0.list_2 = new List<GClass1>();
		}
		return Class0.list_2;
	}

	// Token: 0x0400000E RID: 14
	internal static List<GClass0> list_0;

	// Token: 0x0400000F RID: 15
	internal static List<GClass0> list_1;

	// Token: 0x04000010 RID: 16
	internal static List<GClass1> list_2;
}
