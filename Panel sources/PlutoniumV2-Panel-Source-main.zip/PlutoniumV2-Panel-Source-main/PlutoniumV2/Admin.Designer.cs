﻿// Token: 0x02000010 RID: 16
public partial class Admin : global::System.Windows.Forms.Form
{
	// Token: 0x06000060 RID: 96 RVA: 0x00004550 File Offset: 0x00002750
	private void InitializeComponent()
	{
		base.SuspendLayout();
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		base.ClientSize = new global::System.Drawing.Size(536, 316);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Admin";
		this.Text = "Admin";
		base.Load += new global::System.EventHandler(this.Admin_Load);
		base.ResumeLayout(false);
	}
}
