﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000012 RID: 18
public partial class Load : Form
{
	// Token: 0x06000063 RID: 99 RVA: 0x00002358 File Offset: 0x00000558
	public Load()
	{
		this.InitializeComponent();
	}

	// Token: 0x06000064 RID: 100 RVA: 0x0000236D File Offset: 0x0000056D
	private void Load_Load(object sender, EventArgs e)
	{
		this.timer_0.Start();
	}

	// Token: 0x06000065 RID: 101 RVA: 0x00004618 File Offset: 0x00002818
	private void timer_0_Tick(object sender, EventArgs e)
	{
		if (base.Opacity > 1.0)
		{
		}
	}

	// Token: 0x06000066 RID: 102 RVA: 0x0000237A File Offset: 0x0000057A
	private void Load_MouseUp(object sender, MouseEventArgs e)
	{
		this.int_0 = 0;
	}

	// Token: 0x06000067 RID: 103 RVA: 0x0000463C File Offset: 0x0000283C
	private void Load_MouseMove(object sender, MouseEventArgs e)
	{
		if (this.int_0 == 1)
		{
			base.SetDesktopLocation(Control.MousePosition.X - this.int_1, Control.MousePosition.Y - this.int_2);
		}
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00002383 File Offset: 0x00000583
	private void Load_MouseDown(object sender, MouseEventArgs e)
	{
		this.int_0 = 1;
		this.int_1 = e.X;
		this.int_2 = e.Y;
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00002050 File Offset: 0x00000250
	private void Load_InputLanguageChanging(object sender, InputLanguageChangingEventArgs e)
	{
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00004684 File Offset: 0x00002884
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0400004D RID: 77
	private int int_0;

	// Token: 0x0400004E RID: 78
	private int int_1;

	// Token: 0x0400004F RID: 79
	private int int_2;
}
