﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

// Token: 0x02000016 RID: 22
[DebuggerNonUserCode]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
[CompilerGenerated]
internal class Class10
{
	// Token: 0x060000A8 RID: 168 RVA: 0x0000210D File Offset: 0x0000030D
	internal Class10()
	{
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060000A9 RID: 169 RVA: 0x00008164 File Offset: 0x00006364
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager_0
	{
		get
		{
			if (Class10.resourceManager_0 == null)
			{
				ResourceManager resourceManager = new ResourceManager("Class10", typeof(Class10).Assembly);
				Class10.resourceManager_0 = resourceManager;
			}
			return Class10.resourceManager_0;
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060000AA RID: 170 RVA: 0x000081A4 File Offset: 0x000063A4
	// (set) Token: 0x060000AB RID: 171 RVA: 0x00002504 File Offset: 0x00000704
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo CultureInfo_0
	{
		get
		{
			return Class10.cultureInfo_0;
		}
		set
		{
			Class10.cultureInfo_0 = value;
		}
	}

	// Token: 0x040000A0 RID: 160
	private static ResourceManager resourceManager_0;

	// Token: 0x040000A1 RID: 161
	private static CultureInfo cultureInfo_0;
}
