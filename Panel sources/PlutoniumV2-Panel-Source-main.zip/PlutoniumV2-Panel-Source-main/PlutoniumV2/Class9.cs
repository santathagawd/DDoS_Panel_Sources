﻿using System;
using System.Collections.Specialized;
using System.Net;

// Token: 0x02000011 RID: 17
internal class Class9
{
	// Token: 0x06000062 RID: 98 RVA: 0x000045DC File Offset: 0x000027DC
	public static byte[] smethod_0(string string_0, NameValueCollection nameValueCollection_0)
	{
		byte[] result;
		using (WebClient webClient = new WebClient())
		{
			result = webClient.UploadValues(string_0, nameValueCollection_0);
		}
		return result;
	}
}
