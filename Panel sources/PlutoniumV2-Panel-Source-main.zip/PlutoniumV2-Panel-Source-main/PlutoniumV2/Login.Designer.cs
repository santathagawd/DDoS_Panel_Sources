﻿// Token: 0x0200000C RID: 12
public partial class Login : global::System.Windows.Forms.Form
{
	// Token: 0x06000044 RID: 68 RVA: 0x00002E58 File Offset: 0x00001058
	private void InitializeComponent()
	{
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Login));
		this.panel1 = new global::System.Windows.Forms.Panel();
		this.button1 = new global::System.Windows.Forms.Button();
		this.label1 = new global::System.Windows.Forms.Label();
		this.checkBox1 = new global::System.Windows.Forms.CheckBox();
		this.button4 = new global::System.Windows.Forms.Button();
		this.button2 = new global::System.Windows.Forms.Button();
		this.linkLabel1 = new global::System.Windows.Forms.LinkLabel();
		this.panel2 = new global::System.Windows.Forms.Panel();
		this.label2 = new global::System.Windows.Forms.Label();
		this.linkLabel2 = new global::System.Windows.Forms.LinkLabel();
		this.textBox1 = new global::System.Windows.Forms.TextBox();
		this.usernameTB = new global::System.Windows.Forms.TextBox();
		this.panel1.SuspendLayout();
		this.panel2.SuspendLayout();
		base.SuspendLayout();
		this.panel1.Controls.Add(this.button1);
		this.panel1.Location = new global::System.Drawing.Point(1, 1);
		this.panel1.Name = "panel1";
		this.panel1.Size = new global::System.Drawing.Size(346, 38);
		this.panel1.TabIndex = 11;
		this.panel1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
		this.panel1.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
		this.panel1.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
		this.panel1.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
		this.button1.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
		this.button1.ForeColor = global::System.Drawing.Color.Gray;
		this.button1.Location = new global::System.Drawing.Point(294, 1);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(52, 35);
		this.button1.TabIndex = 0;
		this.button1.Text = "X";
		this.button1.UseVisualStyleBackColor = false;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		this.label1.AutoSize = true;
		this.label1.Font = new global::System.Drawing.Font("Bauhaus 93", 15.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.label1.ForeColor = global::System.Drawing.Color.Gray;
		this.label1.Location = new global::System.Drawing.Point(112, 42);
		this.label1.Name = "label1";
		this.label1.Size = new global::System.Drawing.Size(116, 24);
		this.label1.TabIndex = 17;
		this.label1.Text = "Panel Login";
		this.checkBox1.AutoSize = true;
		this.checkBox1.BackColor = global::System.Drawing.Color.Transparent;
		this.checkBox1.ForeColor = global::System.Drawing.Color.White;
		this.checkBox1.Location = new global::System.Drawing.Point(49, 195);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new global::System.Drawing.Size(97, 17);
		this.checkBox1.TabIndex = 16;
		this.checkBox1.Text = "Hide Password";
		this.checkBox1.UseVisualStyleBackColor = false;
		this.checkBox1.CheckedChanged += new global::System.EventHandler(this.checkBox1_CheckedChanged);
		this.button4.BackColor = global::System.Drawing.Color.Gray;
		this.button4.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.button4.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.button4.Location = new global::System.Drawing.Point(49, 218);
		this.button4.Name = "button4";
		this.button4.Size = new global::System.Drawing.Size(247, 34);
		this.button4.TabIndex = 22;
		this.button4.Text = "Login";
		this.button4.UseCompatibleTextRendering = true;
		this.button4.UseVisualStyleBackColor = false;
		this.button4.Click += new global::System.EventHandler(this.button4_Click);
		this.button2.BackColor = global::System.Drawing.Color.Gray;
		this.button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.button2.ForeColor = global::System.Drawing.SystemColors.ControlText;
		this.button2.Location = new global::System.Drawing.Point(49, 258);
		this.button2.Name = "button2";
		this.button2.Size = new global::System.Drawing.Size(247, 34);
		this.button2.TabIndex = 23;
		this.button2.Text = "Go To Register";
		this.button2.UseCompatibleTextRendering = true;
		this.button2.UseVisualStyleBackColor = false;
		this.button2.Click += new global::System.EventHandler(this.button2_Click);
		this.linkLabel1.AutoSize = true;
		this.linkLabel1.LinkColor = global::System.Drawing.Color.White;
		this.linkLabel1.Location = new global::System.Drawing.Point(125, 323);
		this.linkLabel1.Name = "linkLabel1";
		this.linkLabel1.Size = new global::System.Drawing.Size(92, 13);
		this.linkLabel1.TabIndex = 24;
		this.linkLabel1.TabStop = true;
		this.linkLabel1.Text = "Forgot Password?";
		this.linkLabel1.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
		this.panel2.BackColor = global::System.Drawing.Color.Gray;
		this.panel2.Controls.Add(this.linkLabel2);
		this.panel2.Controls.Add(this.label2);
		this.panel2.Location = new global::System.Drawing.Point(-6, 339);
		this.panel2.Name = "panel2";
		this.panel2.Size = new global::System.Drawing.Size(364, 32);
		this.panel2.TabIndex = 25;
		this.label2.AutoSize = true;
		this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.label2.ForeColor = global::System.Drawing.Color.Black;
		this.label2.Location = new global::System.Drawing.Point(66, 6);
		this.label2.Name = "label2";
		this.label2.Size = new global::System.Drawing.Size(217, 18);
		this.label2.TabIndex = 19;
		this.label2.Text = "Safeugard Auth | xoxo Ovuy";
		this.linkLabel2.ActiveLinkColor = global::System.Drawing.Color.Crimson;
		this.linkLabel2.AutoSize = true;
		this.linkLabel2.LinkColor = global::System.Drawing.Color.Crimson;
		this.linkLabel2.Location = new global::System.Drawing.Point(345, 29);
		this.linkLabel2.Name = "linkLabel2";
		this.linkLabel2.Size = new global::System.Drawing.Size(55, 13);
		this.linkLabel2.TabIndex = 20;
		this.linkLabel2.TabStop = true;
		this.linkLabel2.Text = "linkLabel2";
		this.linkLabel2.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
		this.textBox1.BackColor = global::System.Drawing.Color.FromArgb(46, 46, 46);
		this.textBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.textBox1.Font = new global::System.Drawing.Font("Arial Narrow", 12f);
		this.textBox1.ForeColor = global::System.Drawing.Color.Gray;
		this.textBox1.Location = new global::System.Drawing.Point(49, 156);
		this.textBox1.Multiline = true;
		this.textBox1.Name = "textBox1";
		this.textBox1.Size = new global::System.Drawing.Size(247, 31);
		this.textBox1.TabIndex = 12;
		this.textBox1.Text = "Password";
		this.textBox1.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		this.usernameTB.BackColor = global::System.Drawing.Color.FromArgb(46, 46, 46);
		this.usernameTB.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.usernameTB.Font = new global::System.Drawing.Font("Arial Narrow", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.usernameTB.ForeColor = global::System.Drawing.Color.Gray;
		this.usernameTB.Location = new global::System.Drawing.Point(49, 108);
		this.usernameTB.Multiline = true;
		this.usernameTB.Name = "usernameTB";
		this.usernameTB.Size = new global::System.Drawing.Size(247, 31);
		this.usernameTB.TabIndex = 10;
		this.usernameTB.Text = "Username";
		this.usernameTB.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		this.usernameTB.TextChanged += new global::System.EventHandler(this.usernameTB_TextChanged);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		base.ClientSize = new global::System.Drawing.Size(345, 372);
		base.Controls.Add(this.panel2);
		base.Controls.Add(this.linkLabel1);
		base.Controls.Add(this.button2);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.button4);
		base.Controls.Add(this.panel1);
		base.Controls.Add(this.usernameTB);
		base.Controls.Add(this.checkBox1);
		base.Controls.Add(this.textBox1);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
		base.Name = "Login";
		base.Opacity = 0.88;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Login";
		base.Load += new global::System.EventHandler(this.Login_Load);
		this.panel1.ResumeLayout(false);
		this.panel2.ResumeLayout(false);
		this.panel2.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400002B RID: 43
	private global::System.Windows.Forms.Panel panel1;

	// Token: 0x0400002C RID: 44
	private global::System.Windows.Forms.Label label1;

	// Token: 0x0400002D RID: 45
	private global::System.Windows.Forms.CheckBox checkBox1;

	// Token: 0x0400002E RID: 46
	private global::System.Windows.Forms.Button button4;

	// Token: 0x0400002F RID: 47
	private global::System.Windows.Forms.Button button2;

	// Token: 0x04000030 RID: 48
	private global::System.Windows.Forms.LinkLabel linkLabel1;

	// Token: 0x04000031 RID: 49
	private global::System.Windows.Forms.Panel panel2;

	// Token: 0x04000032 RID: 50
	private global::System.Windows.Forms.Label label2;

	// Token: 0x04000033 RID: 51
	private global::System.Windows.Forms.Button button1;

	// Token: 0x04000034 RID: 52
	private global::System.Windows.Forms.LinkLabel linkLabel2;

	// Token: 0x04000035 RID: 53
	private global::System.Windows.Forms.TextBox textBox1;

	// Token: 0x04000036 RID: 54
	private global::System.Windows.Forms.TextBox usernameTB;
}
