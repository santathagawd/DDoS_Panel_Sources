﻿using System;

// Token: 0x02000009 RID: 9
internal static class Class4
{
	// Token: 0x0400001B RID: 27
	internal static string string_0 = "a1513ab6-7082-4bd4-8a14-713510d26696";
}
