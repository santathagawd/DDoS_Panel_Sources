﻿// Token: 0x02000015 RID: 21
public partial class Reset : global::System.Windows.Forms.Form
{
	// Token: 0x060000A7 RID: 167 RVA: 0x00007A98 File Offset: 0x00005C98
	private void InitializeComponent()
	{
		this.panel1 = new global::System.Windows.Forms.Panel();
		this.label7 = new global::System.Windows.Forms.Label();
		this.label6 = new global::System.Windows.Forms.Label();
		this.button1 = new global::System.Windows.Forms.Button();
		this.tokenTB = new global::System.Windows.Forms.TextBox();
		this.passTB = new global::System.Windows.Forms.TextBox();
		this.ResetBtn = new global::System.Windows.Forms.Button();
		this.usernameTB = new global::System.Windows.Forms.TextBox();
		this.panel1.SuspendLayout();
		base.SuspendLayout();
		this.panel1.Controls.Add(this.label7);
		this.panel1.Controls.Add(this.label6);
		this.panel1.Location = new global::System.Drawing.Point(-6, 0);
		this.panel1.Name = "panel1";
		this.panel1.Size = new global::System.Drawing.Size(352, 36);
		this.panel1.TabIndex = 0;
		this.panel1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
		this.label7.AutoSize = true;
		this.label7.BackColor = global::System.Drawing.Color.Gray;
		this.label7.Font = new global::System.Drawing.Font("Bauhaus 93", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.label7.ForeColor = global::System.Drawing.Color.White;
		this.label7.Location = new global::System.Drawing.Point(212, 9);
		this.label7.Name = "label7";
		this.label7.Size = new global::System.Drawing.Size(16, 18);
		this.label7.TabIndex = 271;
		this.label7.Text = "_";
		this.label7.Click += new global::System.EventHandler(this.label7_Click);
		this.label6.AutoSize = true;
		this.label6.BackColor = global::System.Drawing.Color.Gray;
		this.label6.Font = new global::System.Drawing.Font("Bauhaus 93", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.label6.ForeColor = global::System.Drawing.Color.White;
		this.label6.Location = new global::System.Drawing.Point(236, 9);
		this.label6.Name = "label6";
		this.label6.Size = new global::System.Drawing.Size(16, 18);
		this.label6.TabIndex = 270;
		this.label6.Text = "X";
		this.label6.Click += new global::System.EventHandler(this.label6_Click);
		this.button1.BackColor = global::System.Drawing.Color.Gray;
		this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
		this.button1.ForeColor = global::System.Drawing.Color.White;
		this.button1.Location = new global::System.Drawing.Point(49, 232);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(152, 22);
		this.button1.TabIndex = 21;
		this.button1.Text = "Back to login!";
		this.button1.UseVisualStyleBackColor = false;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		this.tokenTB.BackColor = global::System.Drawing.Color.FromArgb(34, 34, 34);
		this.tokenTB.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.tokenTB.Font = new global::System.Drawing.Font("Segoe UI", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.tokenTB.ForeColor = global::System.Drawing.Color.White;
		this.tokenTB.Location = new global::System.Drawing.Point(49, 136);
		this.tokenTB.Multiline = true;
		this.tokenTB.Name = "tokenTB";
		this.tokenTB.Size = new global::System.Drawing.Size(152, 27);
		this.tokenTB.TabIndex = 20;
		this.tokenTB.Text = "Token";
		this.passTB.BackColor = global::System.Drawing.Color.FromArgb(34, 34, 34);
		this.passTB.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.passTB.Font = new global::System.Drawing.Font("Segoe UI", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
		this.passTB.ForeColor = global::System.Drawing.Color.White;
		this.passTB.Location = new global::System.Drawing.Point(49, 103);
		this.passTB.Multiline = true;
		this.passTB.Name = "passTB";
		this.passTB.Size = new global::System.Drawing.Size(152, 27);
		this.passTB.TabIndex = 19;
		this.passTB.Text = "Password";
		this.ResetBtn.BackColor = global::System.Drawing.Color.Gray;
		this.ResetBtn.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
		this.ResetBtn.ForeColor = global::System.Drawing.Color.White;
		this.ResetBtn.Location = new global::System.Drawing.Point(49, 170);
		this.ResetBtn.Name = "ResetBtn";
		this.ResetBtn.Size = new global::System.Drawing.Size(152, 59);
		this.ResetBtn.TabIndex = 16;
		this.ResetBtn.Text = "Reset Password";
		this.ResetBtn.UseVisualStyleBackColor = false;
		this.ResetBtn.Click += new global::System.EventHandler(this.ResetBtn_Click);
		this.usernameTB.BackColor = global::System.Drawing.Color.FromArgb(34, 34, 34);
		this.usernameTB.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
		this.usernameTB.Font = new global::System.Drawing.Font("Segoe UI", 9.75f);
		this.usernameTB.ForeColor = global::System.Drawing.Color.White;
		this.usernameTB.Location = new global::System.Drawing.Point(49, 70);
		this.usernameTB.Multiline = true;
		this.usernameTB.Name = "usernameTB";
		this.usernameTB.Size = new global::System.Drawing.Size(152, 27);
		this.usernameTB.TabIndex = 17;
		this.usernameTB.Text = "Username";
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		base.ClientSize = new global::System.Drawing.Size(252, 269);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.tokenTB);
		base.Controls.Add(this.passTB);
		base.Controls.Add(this.ResetBtn);
		base.Controls.Add(this.usernameTB);
		base.Controls.Add(this.panel1);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Reset";
		this.Text = "Reset";
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000098 RID: 152
	private global::System.Windows.Forms.Panel panel1;

	// Token: 0x04000099 RID: 153
	private global::System.Windows.Forms.Label label7;

	// Token: 0x0400009A RID: 154
	private global::System.Windows.Forms.Label label6;

	// Token: 0x0400009B RID: 155
	private global::System.Windows.Forms.Button button1;

	// Token: 0x0400009C RID: 156
	private global::System.Windows.Forms.TextBox tokenTB;

	// Token: 0x0400009D RID: 157
	private global::System.Windows.Forms.TextBox passTB;

	// Token: 0x0400009E RID: 158
	private global::System.Windows.Forms.Button ResetBtn;

	// Token: 0x0400009F RID: 159
	private global::System.Windows.Forms.TextBox usernameTB;
}
