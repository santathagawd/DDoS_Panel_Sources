﻿using System;

// Token: 0x02000018 RID: 24
internal class ConfusedByAttribute : Attribute
{
	// Token: 0x060000AF RID: 175 RVA: 0x0000252A File Offset: 0x0000072A
	public ConfusedByAttribute(string string_0)
	{
	}
}
