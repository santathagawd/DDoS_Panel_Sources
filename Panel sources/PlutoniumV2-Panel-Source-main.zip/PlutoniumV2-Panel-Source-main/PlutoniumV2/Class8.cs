﻿using System;
using System.Windows.Forms;

// Token: 0x0200000F RID: 15
internal static class Class8
{
	// Token: 0x06000059 RID: 89 RVA: 0x00002302 File Offset: 0x00000502
	[STAThread]
	private static void Main()
	{
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		Application.Run(new Login());
	}
}
