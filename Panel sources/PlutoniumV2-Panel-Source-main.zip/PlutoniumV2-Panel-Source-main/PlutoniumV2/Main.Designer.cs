﻿// Token: 0x02000014 RID: 20
public partial class Main : global::System.Windows.Forms.Form
{
	// Token: 0x0600009E RID: 158 RVA: 0x000057F8 File Offset: 0x000039F8
	private void InitializeComponent()
	{
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.updatePictureBox = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.timer_0 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.level = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.totserver = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tottoken = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.totuser = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.History = new System.Windows.Forms.ListBox();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.imageList_0 = new System.Windows.Forms.ImageList(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer_1 = new System.Windows.Forms.Timer(this.components);
            this.timeTB = new System.Windows.Forms.TextBox();
            this.portTB = new System.Windows.Forms.TextBox();
            this.ipTB = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.timer_2 = new System.Windows.Forms.Timer(this.components);
            this.timer_3 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updatePictureBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.panel1.Controls.Add(this.updatePictureBox);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Location = new System.Drawing.Point(0, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(611, 36);
            this.panel1.TabIndex = 4;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // updatePictureBox
            // 
            this.updatePictureBox.BackColor = System.Drawing.Color.Transparent;
            this.updatePictureBox.Location = new System.Drawing.Point(3, 0);
            this.updatePictureBox.Name = "updatePictureBox";
            this.updatePictureBox.Size = new System.Drawing.Size(51, 36);
            this.updatePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.updatePictureBox.TabIndex = 4;
            this.updatePictureBox.TabStop = false;
            this.updatePictureBox.Visible = false;
            this.updatePictureBox.Click += new System.EventHandler(this.updatePictureBox_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Gray;
            this.label7.Font = new System.Drawing.Font("Bauhaus 93", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(551, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 18);
            this.label7.TabIndex = 269;
            this.label7.Text = "_";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Gray;
            this.label6.Font = new System.Drawing.Font("Bauhaus 93", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(575, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 18);
            this.label6.TabIndex = 268;
            this.label6.Text = "X";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bauhaus 93", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(236, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(130, 24);
            this.label9.TabIndex = 34;
            this.label9.Text = "Plutonium V2";
            // 
            // timer_0
            // 
            this.timer_0.Tick += new System.EventHandler(this.timer_0_Tick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LimeGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(181, 253);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 34);
            this.button1.TabIndex = 23;
            this.button1.Text = "Start";
            this.button1.UseCompatibleTextRendering = true;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(308, 253);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 34);
            this.button2.TabIndex = 24;
            this.button2.Text = "Stop";
            this.button2.UseCompatibleTextRendering = true;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(16, 86);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(145, 34);
            this.button3.TabIndex = 25;
            this.button3.Text = "IP Lookup";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(16, 126);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(145, 34);
            this.button5.TabIndex = 26;
            this.button5.Text = "Attack Logs";
            this.button5.UseCompatibleTextRendering = true;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(16, 46);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(145, 34);
            this.button6.TabIndex = 27;
            this.button6.Text = "Ping";
            this.button6.UseCompatibleTextRendering = true;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(8, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Username:";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.ForeColor = System.Drawing.Color.Gray;
            this.username.Location = new System.Drawing.Point(67, 16);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(13, 13);
            this.username.TabIndex = 29;
            this.username.Text = "?";
            this.username.Click += new System.EventHandler(this.username_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.level);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.email);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.username);
            this.groupBox1.Location = new System.Drawing.Point(424, 265);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(167, 105);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(8, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 36;
            this.label2.Text = "Mods:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(45, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 37;
            this.label4.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(8, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 32;
            this.label5.Text = "Level:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // level
            // 
            this.level.AutoSize = true;
            this.level.ForeColor = System.Drawing.Color.Gray;
            this.level.Location = new System.Drawing.Point(44, 57);
            this.level.Name = "level";
            this.level.Size = new System.Drawing.Size(13, 13);
            this.level.TabIndex = 33;
            this.level.Text = "?";
            this.level.Click += new System.EventHandler(this.level_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(8, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "Email:";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.ForeColor = System.Drawing.Color.Gray;
            this.email.Location = new System.Drawing.Point(41, 37);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(13, 13);
            this.email.TabIndex = 31;
            this.email.Text = "?";
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(5, 35);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(167, 225);
            this.listBox2.TabIndex = 34;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.totserver);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.tottoken);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.totuser);
            this.groupBox3.Location = new System.Drawing.Point(5, 265);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(167, 105);
            this.groupBox3.TabIndex = 36;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(9, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "Admins: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Gray;
            this.label11.Location = new System.Drawing.Point(56, 77);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 35;
            this.label11.Text = "3";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(8, 57);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "Total Servers:";
            // 
            // totserver
            // 
            this.totserver.AutoSize = true;
            this.totserver.ForeColor = System.Drawing.Color.Gray;
            this.totserver.Location = new System.Drawing.Point(87, 57);
            this.totserver.Name = "totserver";
            this.totserver.Size = new System.Drawing.Size(13, 13);
            this.totserver.TabIndex = 33;
            this.totserver.Text = "?";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Gray;
            this.label14.Location = new System.Drawing.Point(8, 37);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = "Total Tokens:";
            // 
            // tottoken
            // 
            this.tottoken.AutoSize = true;
            this.tottoken.ForeColor = System.Drawing.Color.Gray;
            this.tottoken.Location = new System.Drawing.Point(81, 37);
            this.tottoken.Name = "tottoken";
            this.tottoken.Size = new System.Drawing.Size(13, 13);
            this.tottoken.TabIndex = 31;
            this.tottoken.Text = "?";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Gray;
            this.label16.Location = new System.Drawing.Point(8, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 28;
            this.label16.Text = "Total Users:";
            // 
            // totuser
            // 
            this.totuser.AutoSize = true;
            this.totuser.ForeColor = System.Drawing.Color.Gray;
            this.totuser.Location = new System.Drawing.Point(72, 16);
            this.totuser.Name = "totuser";
            this.totuser.Size = new System.Drawing.Size(13, 13);
            this.totuser.TabIndex = 29;
            this.totuser.Text = "?";
            this.totuser.Click += new System.EventHandler(this.totuser_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(16, 166);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(145, 34);
            this.button7.TabIndex = 37;
            this.button7.Text = "MOTD";
            this.button7.UseCompatibleTextRendering = true;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(181, 185);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(234, 21);
            this.progressBar1.TabIndex = 265;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // History
            // 
            this.History.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.History.ForeColor = System.Drawing.Color.Gray;
            this.History.FormattingEnabled = true;
            this.History.Location = new System.Drawing.Point(424, 35);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(167, 225);
            this.History.TabIndex = 321;
            // 
            // linkLabel4
            // 
            this.linkLabel4.ActiveLinkColor = System.Drawing.Color.LimeGreen;
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.ForeColor = System.Drawing.Color.Gray;
            this.linkLabel4.LinkColor = System.Drawing.Color.Gray;
            this.linkLabel4.Location = new System.Drawing.Point(491, 249);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(31, 13);
            this.linkLabel4.TabIndex = 323;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "Clear";
            this.linkLabel4.VisitedLinkColor = System.Drawing.Color.Red;
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // imageList_0
            // 
            this.imageList_0.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList_0.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList_0.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pictureBox3);
            this.groupBox4.Controls.Add(this.pictureBox2);
            this.groupBox4.Controls.Add(this.pictureBox1);
            this.groupBox4.Location = new System.Drawing.Point(181, 293);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(234, 77);
            this.groupBox4.TabIndex = 324;
            this.groupBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(152, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(70, 53);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(77, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(69, 53);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(8, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // timer_1
            // 
            this.timer_1.Interval = 1000;
            this.timer_1.Tick += new System.EventHandler(this.timer_1_Tick);
            // 
            // timeTB
            // 
            this.timeTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.timeTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.timeTB.ForeColor = System.Drawing.Color.White;
            this.timeTB.Location = new System.Drawing.Point(181, 144);
            this.timeTB.Multiline = true;
            this.timeTB.Name = "timeTB";
            this.timeTB.Size = new System.Drawing.Size(234, 27);
            this.timeTB.TabIndex = 327;
            this.timeTB.Text = "10";
            this.timeTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // portTB
            // 
            this.portTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.portTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.portTB.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.portTB.ForeColor = System.Drawing.Color.White;
            this.portTB.Location = new System.Drawing.Point(181, 99);
            this.portTB.Multiline = true;
            this.portTB.Name = "portTB";
            this.portTB.Size = new System.Drawing.Size(234, 27);
            this.portTB.TabIndex = 326;
            this.portTB.Text = "53";
            this.portTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ipTB
            // 
            this.ipTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.ipTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ipTB.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.ipTB.ForeColor = System.Drawing.Color.White;
            this.ipTB.Location = new System.Drawing.Point(181, 54);
            this.ipTB.Multiline = true;
            this.ipTB.Name = "ipTB";
            this.ipTB.Size = new System.Drawing.Size(234, 27);
            this.ipTB.TabIndex = 325;
            this.ipTB.Text = "127.0.0.1";
            this.ipTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(178, 38);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(64, 13);
            this.label41.TabIndex = 328;
            this.label41.Text = "IP Address :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(178, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 13);
            this.label8.TabIndex = 329;
            this.label8.Text = "Port :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(178, 129);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 13);
            this.label13.TabIndex = 330;
            this.label13.Text = "Time :";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(16, 208);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(145, 34);
            this.button4.TabIndex = 331;
            this.button4.Text = "Admin";
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // timer_2
            // 
            this.timer_2.Tick += new System.EventHandler(this.timer_2_Tick);
            // 
            // timer_3
            // 
            this.timer_3.Tick += new System.EventHandler(this.timer_3_Tick);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ClientSize = new System.Drawing.Size(595, 374);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.timeTB);
            this.Controls.Add(this.portTB);
            this.Controls.Add(this.ipTB);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.History);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.Opacity = 0.98D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updatePictureBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

	}

	// Token: 0x04000064 RID: 100
	private global::System.ComponentModel.IContainer icontainer_0 = null;

	// Token: 0x04000065 RID: 101
	private global::System.Windows.Forms.Panel panel1;

	// Token: 0x04000066 RID: 102
	private global::System.Windows.Forms.Timer timer_0;

	// Token: 0x04000067 RID: 103
	private global::System.Windows.Forms.Button button1;

	// Token: 0x04000068 RID: 104
	private global::System.Windows.Forms.Button button2;

	// Token: 0x04000069 RID: 105
	private global::System.Windows.Forms.Button button3;

	// Token: 0x0400006A RID: 106
	private global::System.Windows.Forms.Button button5;

	// Token: 0x0400006B RID: 107
	private global::System.Windows.Forms.Button button6;

	// Token: 0x0400006C RID: 108
	private global::System.Windows.Forms.Label label1;

	// Token: 0x0400006D RID: 109
	private global::System.Windows.Forms.Label username;

	// Token: 0x0400006E RID: 110
	private global::System.Windows.Forms.GroupBox groupBox1;

	// Token: 0x0400006F RID: 111
	private global::System.Windows.Forms.Label label5;

	// Token: 0x04000070 RID: 112
	private global::System.Windows.Forms.Label level;

	// Token: 0x04000071 RID: 113
	private global::System.Windows.Forms.Label label3;

	// Token: 0x04000072 RID: 114
	private global::System.Windows.Forms.Label email;

	// Token: 0x04000073 RID: 115
	private global::System.Windows.Forms.Label label9;

	// Token: 0x04000074 RID: 116
	private global::System.Windows.Forms.ListBox listBox2;

	// Token: 0x04000075 RID: 117
	private global::System.Windows.Forms.GroupBox groupBox3;

	// Token: 0x04000076 RID: 118
	private global::System.Windows.Forms.Label label10;

	// Token: 0x04000077 RID: 119
	private global::System.Windows.Forms.Label label11;

	// Token: 0x04000078 RID: 120
	private global::System.Windows.Forms.Label label12;

	// Token: 0x04000079 RID: 121
	private global::System.Windows.Forms.Label totserver;

	// Token: 0x0400007A RID: 122
	private global::System.Windows.Forms.Label label14;

	// Token: 0x0400007B RID: 123
	private global::System.Windows.Forms.Label tottoken;

	// Token: 0x0400007C RID: 124
	private global::System.Windows.Forms.Label label16;

	// Token: 0x0400007D RID: 125
	private global::System.Windows.Forms.Label totuser;

	// Token: 0x0400007E RID: 126
	private global::System.Windows.Forms.Button button7;

	// Token: 0x0400007F RID: 127
	private global::System.Windows.Forms.ProgressBar progressBar1;

	// Token: 0x04000080 RID: 128
	private global::LogIn_Theme_Dll_By_xVenoxi.LogInComboBox Methods;

	// Token: 0x04000081 RID: 129
	private global::System.Windows.Forms.ListBox History;

	// Token: 0x04000082 RID: 130
	private global::System.Windows.Forms.LinkLabel linkLabel4;

	// Token: 0x04000083 RID: 131
	private global::System.Windows.Forms.ImageList imageList_0;

	// Token: 0x04000084 RID: 132
	private global::System.Windows.Forms.Label label2;

	// Token: 0x04000085 RID: 133
	private global::System.Windows.Forms.Label label4;

	// Token: 0x04000086 RID: 134
	private global::System.Windows.Forms.GroupBox groupBox4;

	// Token: 0x04000087 RID: 135
	private global::System.Windows.Forms.PictureBox pictureBox2;

	// Token: 0x04000088 RID: 136
	private global::System.Windows.Forms.PictureBox pictureBox1;

	// Token: 0x04000089 RID: 137
	private global::System.Windows.Forms.Timer timer_1;

	// Token: 0x0400008A RID: 138
	private global::System.Windows.Forms.Label label6;

	// Token: 0x0400008B RID: 139
	private global::System.Windows.Forms.Label label7;

	// Token: 0x0400008C RID: 140
	private global::System.Windows.Forms.PictureBox pictureBox3;

	// Token: 0x0400008D RID: 141
	private global::System.Windows.Forms.TextBox timeTB;

	// Token: 0x0400008E RID: 142
	private global::System.Windows.Forms.TextBox portTB;

	// Token: 0x0400008F RID: 143
	private global::System.Windows.Forms.TextBox ipTB;

	// Token: 0x04000090 RID: 144
	private global::System.Windows.Forms.Label label41;

	// Token: 0x04000091 RID: 145
	private global::System.Windows.Forms.Label label8;

	// Token: 0x04000092 RID: 146
	private global::System.Windows.Forms.Label label13;

	// Token: 0x04000093 RID: 147
	private global::System.Windows.Forms.Button button4;

	// Token: 0x04000094 RID: 148
	private global::System.Windows.Forms.Timer timer_2;

	// Token: 0x04000095 RID: 149
	private global::System.Windows.Forms.Timer timer_3;

	// Token: 0x04000096 RID: 150
	private global::System.Windows.Forms.PictureBox updatePictureBox;
    private System.ComponentModel.IContainer components;
}
