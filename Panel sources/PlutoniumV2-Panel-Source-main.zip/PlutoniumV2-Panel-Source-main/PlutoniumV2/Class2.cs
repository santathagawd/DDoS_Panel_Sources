﻿using System;
using SafeGuard;

// Token: 0x02000007 RID: 7
internal static class Class2
{
	// Token: 0x0600002C RID: 44 RVA: 0x0000217B File Offset: 0x0000037B
	internal static void smethod_0()
	{
		ClientFunctions.AutoUpdate(Class2.string_0, Class4.string_0);
	}

	// Token: 0x04000015 RID: 21
	internal static string string_0 = "1";
}
