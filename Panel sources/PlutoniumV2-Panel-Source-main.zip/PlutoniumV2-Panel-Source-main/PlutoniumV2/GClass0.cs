﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000002 RID: 2
public class GClass0
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000002 RID: 2 RVA: 0x00002052 File Offset: 0x00000252
	// (set) Token: 0x06000003 RID: 3 RVA: 0x0000205A File Offset: 0x0000025A
	public long Int64_0 { get; set; }

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000004 RID: 4 RVA: 0x00002063 File Offset: 0x00000263
	// (set) Token: 0x06000005 RID: 5 RVA: 0x0000206B File Offset: 0x0000026B
	public string String_0 { get; set; }

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000006 RID: 6 RVA: 0x00002074 File Offset: 0x00000274
	// (set) Token: 0x06000007 RID: 7 RVA: 0x0000207C File Offset: 0x0000027C
	public int Int32_0 { get; set; }

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000008 RID: 8 RVA: 0x00002085 File Offset: 0x00000285
	// (set) Token: 0x06000009 RID: 9 RVA: 0x0000208D File Offset: 0x0000028D
	public int Int32_1 { get; set; }

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600000A RID: 10 RVA: 0x00002096 File Offset: 0x00000296
	// (set) Token: 0x0600000B RID: 11 RVA: 0x0000209E File Offset: 0x0000029E
	public string String_1 { get; set; }

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x0600000C RID: 12 RVA: 0x000020A7 File Offset: 0x000002A7
	// (set) Token: 0x0600000D RID: 13 RVA: 0x000020AF File Offset: 0x000002AF
	public string String_2 { get; set; }

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x0600000E RID: 14 RVA: 0x000020B8 File Offset: 0x000002B8
	// (set) Token: 0x0600000F RID: 15 RVA: 0x000020C0 File Offset: 0x000002C0
	public string String_3 { get; set; }

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000010 RID: 16 RVA: 0x000020C9 File Offset: 0x000002C9
	// (set) Token: 0x06000011 RID: 17 RVA: 0x000020D1 File Offset: 0x000002D1
	public long Int64_1 { get; set; }

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000012 RID: 18 RVA: 0x000020DA File Offset: 0x000002DA
	// (set) Token: 0x06000013 RID: 19 RVA: 0x000020E2 File Offset: 0x000002E2
	public DateTime DateTime_0 { get; set; }

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000014 RID: 20 RVA: 0x000020EB File Offset: 0x000002EB
	// (set) Token: 0x06000015 RID: 21 RVA: 0x000020F3 File Offset: 0x000002F3
	public bool Boolean_0 { get; set; }

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x06000016 RID: 22 RVA: 0x000020FC File Offset: 0x000002FC
	// (set) Token: 0x06000017 RID: 23 RVA: 0x00002104 File Offset: 0x00000304
	public long Int64_2 { get; set; }

	// Token: 0x04000001 RID: 1
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private long long_0;

	// Token: 0x04000002 RID: 2
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_0;

	// Token: 0x04000003 RID: 3
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int int_0;

	// Token: 0x04000004 RID: 4
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int int_1;

	// Token: 0x04000005 RID: 5
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_1;

	// Token: 0x04000006 RID: 6
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_2;

	// Token: 0x04000007 RID: 7
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private string string_3;

	// Token: 0x04000008 RID: 8
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private long long_1;

	// Token: 0x04000009 RID: 9
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private DateTime dateTime_0;

	// Token: 0x0400000A RID: 10
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_0;

	// Token: 0x0400000B RID: 11
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private long long_2;
}
