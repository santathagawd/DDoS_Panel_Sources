﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
//using SafeGuard;

// Token: 0x0200000E RID: 14
public partial class Form1 : Form
{
	// Token: 0x06000048 RID: 72 RVA: 0x00002292 File Offset: 0x00000492
	public Form1()
	{
		this.InitializeComponent();
	}

	// Token: 0x06000049 RID: 73 RVA: 0x00002050 File Offset: 0x00000250
	private void panel1_Paint(object sender, PaintEventArgs e)
	{
	}

	// Token: 0x0600004A RID: 74 RVA: 0x0000386C File Offset: 0x00001A6C
	private void panel1_MouseMove(object sender, MouseEventArgs e)
	{
		if (this.int_0 == 1)
		{
			base.SetDesktopLocation(Control.MousePosition.X - this.int_2, Control.MousePosition.Y - this.int_1);
		}
	}

	// Token: 0x0600004B RID: 75 RVA: 0x00002050 File Offset: 0x00000250
	private void Form1_Load(object sender, EventArgs e)
	{
	}

	// Token: 0x0600004C RID: 76 RVA: 0x000022A7 File Offset: 0x000004A7
	private void panel1_MouseDown(object sender, MouseEventArgs e)
	{
		this.int_0 = 1;
		this.int_2 = e.X;
		this.int_1 = e.Y;
	}

	// Token: 0x0600004D RID: 77 RVA: 0x000022C8 File Offset: 0x000004C8
	private void panel1_MouseUp(object sender, MouseEventArgs e)
	{
		this.int_0 = 0;
	}

	// Token: 0x0600004E RID: 78 RVA: 0x00002205 File Offset: 0x00000405
	private void button1_Click(object sender, EventArgs e)
	{
		Environment.Exit(0);
	}

	// Token: 0x0600004F RID: 79 RVA: 0x000038B4 File Offset: 0x00001AB4
	private void Register_Click(object sender, EventArgs e)
	{
//		Class3.registerInformationObject_0 = ClientFunctions.Register(this.userTB.Text, this.passTB.Text, this.tokenTB.Text, this.emailTB.Text, Class4.string_0);
		if (!Class3.registerInformationObject_0.Failure)
		{
//			Class3.loginResponse_0 = ClientFunctions.Login(this.userTB.Text, this.passTB.Text, Class4.string_0);
			if (Class3.loginResponse_0.Failure)
			{
				MessageBox.Show(Class3.loginResponse_0.Message);
			}
			else
			{
				MessageBox.Show(string.Concat(new string[]
				{
					"Welcome ",
					this.userTB.Text,
					Environment.NewLine,
					"Using Token: ",
					this.tokenTB.Text,
					Environment.NewLine,
					"Email: ",
					this.emailTB.Text
				}), "Welcome To Plutonium.");
				Class3.string_0 = this.passTB.Text;
				base.Hide();
				Login login = new Login();
				login.ShowDialog();
				base.Close();
			}
		}
		else
		{
			MessageBox.Show(Class3.registerInformationObject_0.Message);
		}
	}

	// Token: 0x06000050 RID: 80 RVA: 0x000022D1 File Offset: 0x000004D1
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		this.passTB.PasswordChar = '*';
	}

	// Token: 0x06000051 RID: 81 RVA: 0x00002050 File Offset: 0x00000250
	private void method_0(object sender, EventArgs e)
	{
	}

	// Token: 0x06000052 RID: 82 RVA: 0x000022E0 File Offset: 0x000004E0
	private void passTB_TextChanged(object sender, EventArgs e)
	{
		this.passTB.MaxLength = 14;
	}

	// Token: 0x06000053 RID: 83 RVA: 0x000022EF File Offset: 0x000004EF
	private void button3_Click(object sender, EventArgs e)
	{
		base.Hide();
		new Login().ShowDialog();
	}

	// Token: 0x06000054 RID: 84 RVA: 0x000039F8 File Offset: 0x00001BF8
	private void method_1(object sender, EventArgs e)
	{
		MessageBox.Show(string.Concat(new string[]
		{
			"30 people joined => 1 day trail on the panel",
			Environment.NewLine,
			"100 people joined => 1 month trail on the panel",
			Environment.NewLine,
			"If you already have a plan we will add the days!",
			Environment.NewLine,
			"200 joins => lifetime!"
		}));
		Process.Start("https://discord.gg/plutoniumv2");
	}

	// Token: 0x06000055 RID: 85 RVA: 0x00002050 File Offset: 0x00000250
	private void panel2_Paint(object sender, PaintEventArgs e)
	{
	}

	// Token: 0x06000056 RID: 86 RVA: 0x00002050 File Offset: 0x00000250
	private void userTB_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00003A5C File Offset: 0x00001C5C
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000039 RID: 57
	private int int_0;

	// Token: 0x0400003A RID: 58
	private int int_1;

	// Token: 0x0400003B RID: 59
	private int int_2;

	// Token: 0x0400003C RID: 60
	private IContainer icontainer_0 = null;
}
