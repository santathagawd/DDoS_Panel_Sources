﻿// Token: 0x0200000E RID: 14
public partial class Form1 : global::System.Windows.Forms.Form
{
	// Token: 0x06000058 RID: 88 RVA: 0x00003A8C File Offset: 0x00001C8C
	private void InitializeComponent()
	{
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Form1));
		this.userTB = new global::System.Windows.Forms.TextBox();
		this.panel1 = new global::System.Windows.Forms.Panel();
		this.button1 = new global::System.Windows.Forms.Button();
		this.passTB = new global::System.Windows.Forms.TextBox();
		this.tokenTB = new global::System.Windows.Forms.TextBox();
		this.emailTB = new global::System.Windows.Forms.TextBox();
		this.Register = new global::System.Windows.Forms.Button();
		this.checkBox1 = new global::System.Windows.Forms.CheckBox();
		this.label1 = new global::System.Windows.Forms.Label();
		this.button3 = new global::System.Windows.Forms.Button();
		this.label2 = new global::System.Windows.Forms.Label();
		this.panel2 = new global::System.Windows.Forms.Panel();
		this.panel1.SuspendLayout();
		this.panel2.SuspendLayout();
		base.SuspendLayout();
		this.userTB.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		this.userTB.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.userTB.Font = new global::System.Drawing.Font("Arial Narrow", 12f);
		this.userTB.ForeColor = global::System.Drawing.Color.Gray;
		this.userTB.Location = new global::System.Drawing.Point(26, 118);
		this.userTB.Multiline = true;
		this.userTB.Name = "userTB";
		this.userTB.Size = new global::System.Drawing.Size(284, 31);
		this.userTB.TabIndex = 0;
		this.userTB.Text = "Username";
		this.userTB.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		this.userTB.TextChanged += new global::System.EventHandler(this.userTB_TextChanged);
		this.panel1.Controls.Add(this.button1);
		this.panel1.Location = new global::System.Drawing.Point(-5, 0);
		this.panel1.Name = "panel1";
		this.panel1.Size = new global::System.Drawing.Size(346, 38);
		this.panel1.TabIndex = 1;
		this.panel1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
		this.panel1.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
		this.panel1.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
		this.panel1.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
		this.button1.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
		this.button1.ForeColor = global::System.Drawing.Color.Gray;
		this.button1.Location = new global::System.Drawing.Point(293, 1);
		this.button1.Name = "button1";
		this.button1.Size = new global::System.Drawing.Size(52, 36);
		this.button1.TabIndex = 0;
		this.button1.Text = "X";
		this.button1.UseVisualStyleBackColor = false;
		this.button1.Click += new global::System.EventHandler(this.button1_Click);
		this.passTB.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		this.passTB.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.passTB.Font = new global::System.Drawing.Font("Arial Narrow", 12f);
		this.passTB.ForeColor = global::System.Drawing.Color.Gray;
		this.passTB.Location = new global::System.Drawing.Point(26, 166);
		this.passTB.Multiline = true;
		this.passTB.Name = "passTB";
		this.passTB.Size = new global::System.Drawing.Size(284, 31);
		this.passTB.TabIndex = 2;
		this.passTB.Text = "Password";
		this.passTB.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		this.passTB.TextChanged += new global::System.EventHandler(this.passTB_TextChanged);
		this.tokenTB.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		this.tokenTB.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.tokenTB.Font = new global::System.Drawing.Font("Arial Narrow", 12f);
		this.tokenTB.ForeColor = global::System.Drawing.Color.Gray;
		this.tokenTB.Location = new global::System.Drawing.Point(26, 215);
		this.tokenTB.Multiline = true;
		this.tokenTB.Name = "tokenTB";
		this.tokenTB.Size = new global::System.Drawing.Size(284, 31);
		this.tokenTB.TabIndex = 3;
		this.tokenTB.Text = "Token";
		this.tokenTB.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		this.emailTB.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		this.emailTB.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
		this.emailTB.Font = new global::System.Drawing.Font("Arial Narrow", 12f);
		this.emailTB.ForeColor = global::System.Drawing.Color.Gray;
		this.emailTB.Location = new global::System.Drawing.Point(26, 261);
		this.emailTB.Multiline = true;
		this.emailTB.Name = "emailTB";
		this.emailTB.Size = new global::System.Drawing.Size(284, 31);
		this.emailTB.TabIndex = 4;
		this.emailTB.Text = "Email";
		this.emailTB.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
		this.Register.BackColor = global::System.Drawing.Color.Gray;
		this.Register.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.Register.Location = new global::System.Drawing.Point(26, 320);
		this.Register.Name = "Register";
		this.Register.Size = new global::System.Drawing.Size(284, 36);
		this.Register.TabIndex = 5;
		this.Register.Text = "Register ";
		this.Register.UseVisualStyleBackColor = false;
		this.Register.Click += new global::System.EventHandler(this.Register_Click);
		this.checkBox1.AutoSize = true;
		this.checkBox1.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		this.checkBox1.ForeColor = global::System.Drawing.Color.White;
		this.checkBox1.Location = new global::System.Drawing.Point(26, 298);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new global::System.Drawing.Size(97, 17);
		this.checkBox1.TabIndex = 6;
		this.checkBox1.Text = "Hide Password";
		this.checkBox1.UseVisualStyleBackColor = false;
		this.checkBox1.CheckedChanged += new global::System.EventHandler(this.checkBox1_CheckedChanged);
		this.label1.AutoSize = true;
		this.label1.Font = new global::System.Drawing.Font("Bauhaus 93", 15.75f);
		this.label1.ForeColor = global::System.Drawing.Color.Gray;
		this.label1.Location = new global::System.Drawing.Point(77, 57);
		this.label1.Name = "label1";
		this.label1.Size = new global::System.Drawing.Size(184, 24);
		this.label1.TabIndex = 7;
		this.label1.Text = "Plutonium Register";
		this.button3.BackColor = global::System.Drawing.Color.Gray;
		this.button3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
		this.button3.Location = new global::System.Drawing.Point(26, 362);
		this.button3.Name = "button3";
		this.button3.Size = new global::System.Drawing.Size(284, 36);
		this.button3.TabIndex = 8;
		this.button3.Text = "Back To Login";
		this.button3.UseVisualStyleBackColor = false;
		this.button3.Click += new global::System.EventHandler(this.button3_Click);
		this.label2.AutoSize = true;
		this.label2.BackColor = global::System.Drawing.Color.Gray;
		this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
		this.label2.ForeColor = global::System.Drawing.Color.Black;
		this.label2.Location = new global::System.Drawing.Point(57, 6);
		this.label2.Name = "label2";
		this.label2.Size = new global::System.Drawing.Size(217, 18);
		this.label2.TabIndex = 9;
		this.label2.Text = "Safeugard Auth | xoxo Ovuy";
		this.panel2.BackColor = global::System.Drawing.Color.Gray;
		this.panel2.Controls.Add(this.label2);
		this.panel2.Location = new global::System.Drawing.Point(2, 429);
		this.panel2.Name = "panel2";
		this.panel2.Size = new global::System.Drawing.Size(339, 32);
		this.panel2.TabIndex = 12;
		this.panel2.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.FromArgb(35, 36, 35);
		base.ClientSize = new global::System.Drawing.Size(340, 459);
		base.Controls.Add(this.button3);
		base.Controls.Add(this.label1);
		base.Controls.Add(this.checkBox1);
		base.Controls.Add(this.Register);
		base.Controls.Add(this.emailTB);
		base.Controls.Add(this.tokenTB);
		base.Controls.Add(this.passTB);
		base.Controls.Add(this.panel1);
		base.Controls.Add(this.userTB);
		base.Controls.Add(this.panel2);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
//		base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
		base.Name = "Form1";
		base.Opacity = 0.88;
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Form1";
		base.Load += new global::System.EventHandler(this.Form1_Load);
		this.panel1.ResumeLayout(false);
		this.panel2.ResumeLayout(false);
		this.panel2.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400003D RID: 61
	private global::System.Windows.Forms.TextBox userTB;

	// Token: 0x0400003E RID: 62
	private global::System.Windows.Forms.Panel panel1;

	// Token: 0x0400003F RID: 63
	private global::System.Windows.Forms.Button button1;

	// Token: 0x04000040 RID: 64
	private global::System.Windows.Forms.TextBox passTB;

	// Token: 0x04000041 RID: 65
	private global::System.Windows.Forms.TextBox tokenTB;

	// Token: 0x04000042 RID: 66
	private global::System.Windows.Forms.TextBox emailTB;

	// Token: 0x04000043 RID: 67
	private global::System.Windows.Forms.Button Register;

	// Token: 0x04000044 RID: 68
	private global::System.Windows.Forms.CheckBox checkBox1;

	// Token: 0x04000045 RID: 69
	private global::System.Windows.Forms.Label label1;

	// Token: 0x04000046 RID: 70
	private global::System.Windows.Forms.Button button3;

	// Token: 0x04000047 RID: 71
	private global::System.Windows.Forms.Label label2;

	// Token: 0x04000048 RID: 72
	private global::System.Windows.Forms.Panel panel2;
}
