﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000010 RID: 16
public partial class Admin : Form
{
	// Token: 0x0600005A RID: 90 RVA: 0x00002319 File Offset: 0x00000519
	public Admin()
	{
		this.InitializeComponent();
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00002050 File Offset: 0x00000250
	private void Admin_Load(object sender, EventArgs e)
	{
	}

	// Token: 0x0600005C RID: 92 RVA: 0x0000232E File Offset: 0x0000052E
	private void method_0(object sender, MouseEventArgs e)
	{
		this.int_0 = 1;
		this.int_1 = e.X;
		this.int_2 = e.Y;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x0000234F File Offset: 0x0000054F
	private void method_1(object sender, MouseEventArgs e)
	{
		this.int_0 = 0;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x000044D8 File Offset: 0x000026D8
	private void method_2(object sender, MouseEventArgs e)
	{
		if (this.int_0 == 1)
		{
			base.SetDesktopLocation(Control.MousePosition.X - this.int_1, Control.MousePosition.Y - this.int_2);
		}
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00004520 File Offset: 0x00002720
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000049 RID: 73
	private int int_0;

	// Token: 0x0400004A RID: 74
	private int int_1;

	// Token: 0x0400004B RID: 75
	private int int_2;

	// Token: 0x0400004C RID: 76
	private IContainer icontainer_0 = null;
}
