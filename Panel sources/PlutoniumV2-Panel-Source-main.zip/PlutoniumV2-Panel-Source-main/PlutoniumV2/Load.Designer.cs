﻿// Token: 0x02000012 RID: 18
public partial class Load : global::System.Windows.Forms.Form
{
	// Token: 0x0600006B RID: 107 RVA: 0x000046B4 File Offset: 0x000028B4
	private void InitializeComponent()
	{
		this.icontainer_0 = new global::System.ComponentModel.Container();
		global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Load));
		this.timer_0 = new global::System.Windows.Forms.Timer(this.icontainer_0);
		base.SuspendLayout();
		this.timer_0.Tick += new global::System.EventHandler(this.timer_0_Tick);
		base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = global::System.Drawing.Color.DarkRed;
//		this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
		base.ClientSize = new global::System.Drawing.Size(634, 609);
		base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
//		base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
		base.Name = "Load";
		base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Load";
		base.Load += new global::System.EventHandler(this.Load_Load);
		base.InputLanguageChanging += new global::System.Windows.Forms.InputLanguageChangingEventHandler(this.Load_InputLanguageChanging);
		base.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.Load_MouseDown);
		base.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.Load_MouseMove);
		base.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.Load_MouseUp);
		base.ResumeLayout(false);
	}

	// Token: 0x04000050 RID: 80
	private global::System.ComponentModel.IContainer icontainer_0 = null;

	// Token: 0x04000051 RID: 81
	private global::System.Windows.Forms.Timer timer_0;
}
