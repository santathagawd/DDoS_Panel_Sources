﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000006 RID: 6
public class GClass2
{
	// Token: 0x1700000E RID: 14
	// (get) Token: 0x06000023 RID: 35 RVA: 0x00002137 File Offset: 0x00000337
	// (set) Token: 0x06000024 RID: 36 RVA: 0x0000213F File Offset: 0x0000033F
	public string String_0 { get; set; }

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000025 RID: 37 RVA: 0x00002148 File Offset: 0x00000348
	// (set) Token: 0x06000026 RID: 38 RVA: 0x00002150 File Offset: 0x00000350
	public string String_1 { get; set; }

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000027 RID: 39 RVA: 0x00002159 File Offset: 0x00000359
	// (set) Token: 0x06000028 RID: 40 RVA: 0x00002161 File Offset: 0x00000361
	public string String_2 { get; set; }

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000029 RID: 41 RVA: 0x0000216A File Offset: 0x0000036A
	// (set) Token: 0x0600002A RID: 42 RVA: 0x00002172 File Offset: 0x00000372
	public string String_3 { get; set; }

	// Token: 0x04000011 RID: 17
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_0;

	// Token: 0x04000012 RID: 18
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private string string_1;

	// Token: 0x04000013 RID: 19
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private string string_2;

	// Token: 0x04000014 RID: 20
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_3;
}
