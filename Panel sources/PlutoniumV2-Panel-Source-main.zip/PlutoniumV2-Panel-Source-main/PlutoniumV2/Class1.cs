﻿using System;
using SafeGuard;

// Token: 0x02000005 RID: 5
internal static class Class1
{
	// Token: 0x06000021 RID: 33 RVA: 0x00002660 File Offset: 0x00000860
	public static void smethod_0(string string_0, string string_1, string string_2, string string_3 = "")
	{
		string_0 = string_0.ToLower();
		string string_4 = "https://i.imgur.com/6leptM3.jpg";
		string text = string_0;
		string a = text;
		string string_5;
		string string_6;
		if (!(a == "login"))
		{
			if (!(a == "geoip"))
			{
				if (!(a == "register"))
				{
					if (!(a == "attack"))
					{
						string_5 = string_1 + " Has Done Unknown Function";
						string_6 = "Infinity Unknown";
					}
					else
					{
						string_5 = string_1 + " Has Just Sent An Attack to " + string_2 + "!";
						string_6 = "Infinity Attack";
					}
				}
				else
				{
					string_5 = string_1 + " Has Registered!";
					string_6 = "Infinity Registrations";
				}
			}
			else
			{
				string_5 = string.Concat(new string[]
				{
					string_1,
					" Has Just GeoLocated this ip: ",
					string_3,
					" from IP: ",
					string_2,
					"!"
				});
				string_6 = "Infinity GeoIP";
			}
		}
		else
		{
			string_5 = string_1 + " Has Just Logged In From " + string_2 + "!";
			string_6 = "Infinity Login";
		}
		Class1.smethod_1("", new GClass2
		{
			String_0 = string_5,
			String_1 = string_6,
			String_2 = string_4,
			String_3 = Class4.string_0
		});
	}

	// Token: 0x06000022 RID: 34 RVA: 0x0000277C File Offset: 0x0000097C
	private static bool smethod_1(string string_0, GClass2 gclass2_0)
	{
		bool result;
		if (gclass2_0 == null)
		{
			result = false;
		}
		else
		{
			try
			{
				Tools.postRequest("https://safeguardauth.us/LogToDiscordv2?apikey=" + string_0, gclass2_0);
			}
			catch
			{
				return false;
			}
			result = true;
		}
		return result;
	}
}
