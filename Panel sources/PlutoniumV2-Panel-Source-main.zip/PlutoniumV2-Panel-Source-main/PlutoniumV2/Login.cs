﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using SafeGuard;

// Token: 0x0200000C RID: 12
public partial class Login : Form
{
	// Token: 0x06000034 RID: 52 RVA: 0x000021B0 File Offset: 0x000003B0
	public Login()
	{
		this.InitializeComponent();
	}

	// Token: 0x06000035 RID: 53 RVA: 0x000021DB File Offset: 0x000003DB
	private void panel1_MouseDown(object sender, MouseEventArgs e)
	{
		this.int_0 = 1;
		this.int_1 = e.X;
		this.int_2 = e.Y;
	}

	// Token: 0x06000036 RID: 54 RVA: 0x000021FC File Offset: 0x000003FC
	private void panel1_MouseUp(object sender, MouseEventArgs e)
	{
		this.int_0 = 0;
	}

	// Token: 0x06000037 RID: 55 RVA: 0x00002CF0 File Offset: 0x00000EF0
	private void panel1_MouseMove(object sender, MouseEventArgs e)
	{
		if (this.int_0 == 1)
		{
			base.SetDesktopLocation(Control.MousePosition.X - this.int_1, Control.MousePosition.Y - this.int_2);
		}
	}

	// Token: 0x06000038 RID: 56 RVA: 0x00002050 File Offset: 0x00000250
	private void Login_Load(object sender, EventArgs e)
	{
	}

	// Token: 0x06000039 RID: 57 RVA: 0x00002050 File Offset: 0x00000250
	private void method_0(object sender, EventArgs e)
	{
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00002050 File Offset: 0x00000250
	private void method_1(object sender, EventArgs e)
	{
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00002D38 File Offset: 0x00000F38
	private void button4_Click(object sender, EventArgs e)
	{
		Class3.loginResponse_0 = ClientFunctions.Login(this.usernameTB.Text, this.textBox1.Text, Class4.string_0);
		Class3.string_0 = this.textBox1.Text;
		if (Class3.loginResponse_0.Failure)
		{
			MessageBox.Show(Class3.loginResponse_0.Message);
		}
		else
		{
			Task.Run(new Action(Login.Class7.<>9.method_0));
			MessageBox.Show(string.Concat(new string[]
			{
				"Welcome To PlutoniumV2",
				Environment.NewLine,
				"Username: ",
				this.usernameTB.Text,
				Environment.NewLine,
				"IP: ",
				Tools.GetClientIP()
			}));
			base.Hide();
			Main main = new Main();
			main.ShowDialog();
			base.Close();
		}
	}

	// Token: 0x0600003C RID: 60 RVA: 0x00002050 File Offset: 0x00000250
	private void panel1_Paint(object sender, PaintEventArgs e)
	{
	}

	// Token: 0x0600003D RID: 61 RVA: 0x00002205 File Offset: 0x00000405
	private void button1_Click(object sender, EventArgs e)
	{
		Environment.Exit(0);
	}

	// Token: 0x0600003E RID: 62 RVA: 0x0000220D File Offset: 0x0000040D
	private void button2_Click(object sender, EventArgs e)
	{
		base.Hide();
		new Form1().ShowDialog();
	}

	// Token: 0x0600003F RID: 63 RVA: 0x00002220 File Offset: 0x00000420
	private void checkBox1_CheckedChanged(object sender, EventArgs e)
	{
		this.textBox1.PasswordChar = '*';
	}

	// Token: 0x06000040 RID: 64 RVA: 0x00002050 File Offset: 0x00000250
	private void usernameTB_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06000041 RID: 65 RVA: 0x0000222F File Offset: 0x0000042F
	private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		this.usernameTB.Text = this.string_0;
		this.textBox1.Text = this.string_1;
	}

	// Token: 0x06000042 RID: 66 RVA: 0x00002253 File Offset: 0x00000453
	private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		base.Hide();
		new Reset().ShowDialog();
	}

	// Token: 0x06000043 RID: 67 RVA: 0x00002E28 File Offset: 0x00001028
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000025 RID: 37
	private int int_0;

	// Token: 0x04000026 RID: 38
	private int int_1;

	// Token: 0x04000027 RID: 39
	private int int_2;

	// Token: 0x04000028 RID: 40
	private string string_0 = "kq";

	// Token: 0x04000029 RID: 41
	private string string_1 = "9876HOUSE!";

	// Token: 0x0400002A RID: 42
	private IContainer icontainer_0 = null;

	// Token: 0x0200000D RID: 13
	[CompilerGenerated]
	[Serializable]
	private sealed class Class7
	{
		// Token: 0x06000047 RID: 71 RVA: 0x00002272 File Offset: 0x00000472
		internal void method_0()
		{
			Class1.smethod_0("login", Class3.loginResponse_0.UserName, Tools.GetClientIP(), "");
		}

		// Token: 0x04000037 RID: 55
		public static readonly Login.Class7 <>9 = new Login.Class7();

		// Token: 0x04000038 RID: 56
		public static Action <>9__12_0;
	}
}
