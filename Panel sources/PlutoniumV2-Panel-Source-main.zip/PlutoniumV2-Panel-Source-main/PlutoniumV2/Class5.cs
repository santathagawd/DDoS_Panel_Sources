﻿using System;

// Token: 0x0200000A RID: 10
internal static class Class5
{
	// Token: 0x0400001C RID: 28
	public static string string_0 = "SafeGuardAuth.us";
}
