﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000003 RID: 3
public class GClass1
{
	// Token: 0x1700000C RID: 12
	// (get) Token: 0x06000019 RID: 25 RVA: 0x00002115 File Offset: 0x00000315
	// (set) Token: 0x0600001A RID: 26 RVA: 0x0000211D File Offset: 0x0000031D
	public string String_0 { get; set; }

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600001B RID: 27 RVA: 0x00002126 File Offset: 0x00000326
	// (set) Token: 0x0600001C RID: 28 RVA: 0x0000212E File Offset: 0x0000032E
	public int Int32_0 { get; set; }

	// Token: 0x0400000C RID: 12
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private string string_0;

	// Token: 0x0400000D RID: 13
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private int int_0;
}
