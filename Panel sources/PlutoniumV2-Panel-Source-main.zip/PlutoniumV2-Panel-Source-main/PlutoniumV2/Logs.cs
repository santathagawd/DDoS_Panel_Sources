﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

// Token: 0x02000013 RID: 19
public partial class Logs : Form
{
	// Token: 0x0600006C RID: 108 RVA: 0x000023A4 File Offset: 0x000005A4
	public Logs()
	{
		this.InitializeComponent();
	}

	// Token: 0x0600006D RID: 109 RVA: 0x000047F8 File Offset: 0x000029F8
	public void method_0()
	{
		try
		{
			if (Directory.Exists(this.string_0))
			{
				this.richTextBox1.Text = File.ReadAllText(this.string_1);
				return;
			}
			Directory.CreateDirectory(this.string_0);
			MessageBox.Show("The directory was created successfully");
		}
		catch (Exception ex)
		{
			MessageBox.Show("The process failed: {0}", ex.ToString());
		}
		finally
		{
		}
		this.method_1();
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00004880 File Offset: 0x00002A80
	public void method_1()
	{
		if (File.Exists(this.string_1))
		{
			this.richTextBox1.Text = File.ReadAllText(this.string_1);
			MessageBox.Show("Log File Already Exist..");
		}
		else
		{
			File.Create(this.string_1);
			MessageBox.Show("Creating Log File.....");
		}
	}

	// Token: 0x0600006F RID: 111 RVA: 0x00002050 File Offset: 0x00000250
	private void panel1_Paint(object sender, PaintEventArgs e)
	{
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00002050 File Offset: 0x00000250
	private void richTextBox1_TextChanged(object sender, EventArgs e)
	{
	}

	// Token: 0x06000071 RID: 113 RVA: 0x000048D4 File Offset: 0x00002AD4
	private void Logs_Load(object sender, EventArgs e)
	{
		this.method_0();
		int num = File.ReadLines(this.string_1).Count<string>();
		this.label2.Text = num.ToString();
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00002050 File Offset: 0x00000250
	private void panel2_Paint(object sender, PaintEventArgs e)
	{
	}

	// Token: 0x06000073 RID: 115 RVA: 0x000023CF File Offset: 0x000005CF
	private void panel2_MouseDown(object sender, MouseEventArgs e)
	{
		this.int_0 = 1;
		this.int_1 = e.X;
		this.int_2 = e.Y;
	}

	// Token: 0x06000074 RID: 116 RVA: 0x000023F0 File Offset: 0x000005F0
	private void panel2_MouseUp(object sender, MouseEventArgs e)
	{
		this.int_0 = 0;
	}

	// Token: 0x06000075 RID: 117 RVA: 0x0000490C File Offset: 0x00002B0C
	private void panel2_MouseMove(object sender, MouseEventArgs e)
	{
		if (this.int_0 == 1)
		{
			base.SetDesktopLocation(Control.MousePosition.X - this.int_1, Control.MousePosition.Y - this.int_2);
		}
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00002050 File Offset: 0x00000250
	private void label2_Click(object sender, EventArgs e)
	{
	}

	// Token: 0x06000077 RID: 119 RVA: 0x000023F9 File Offset: 0x000005F9
	private void label12_Click(object sender, EventArgs e)
	{
		base.Hide();
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00004954 File Offset: 0x00002B54
	protected virtual void Dispose(bool disposing)
	{
		if (disposing && this.icontainer_0 != null)
		{
			this.icontainer_0.Dispose();
		}
		base.Dispose(disposing);
	}

	// Token: 0x04000052 RID: 82
	private string string_0 = "C:\\ProgramData\\synicityservices";

	// Token: 0x04000053 RID: 83
	private string string_1 = "C:\\ProgramData\\synicityservices\\AttackInfo.json";

	// Token: 0x04000054 RID: 84
	private int int_0;

	// Token: 0x04000055 RID: 85
	private int int_1;

	// Token: 0x04000056 RID: 86
	private int int_2;

	// Token: 0x04000057 RID: 87
	private IContainer icontainer_0 = null;

    private void label4_Click(object sender, EventArgs e)
    {

    }
}
