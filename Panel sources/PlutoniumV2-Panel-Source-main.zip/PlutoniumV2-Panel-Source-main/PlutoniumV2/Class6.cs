﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

// Token: 0x0200000B RID: 11
internal class Class6
{
	// Token: 0x06000030 RID: 48 RVA: 0x000027C0 File Offset: 0x000009C0
	internal static void smethod_0()
	{
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "SafeGuard.dll", "MD5") != Class6.string_0)
		{
			MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "SafeGuard.dll", "SHA1") != Class6.string_1)
		{
			MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "SafeGuard.dll", "SHA256") != Class6.string_2)
		{
			MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "SafeGuard.dll", "SIZE") != Class6.string_3)
		{
			MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "Newtonsoft.Json.dll", "MD5") != Class6.string_4)
		{
			MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "Newtonsoft.Json.dll", "SHA1") != Class6.string_5)
		{
			MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "Newtonsoft.Json.dll", "SHA256") != Class6.string_6)
		{
			MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
		if (Class6.smethod_1(AppDomain.CurrentDomain.BaseDirectory + "Newtonsoft.Json.dll", "SIZE") != Class6.string_7)
		{
			MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", Class5.string_0);
			Environment.Exit(2134);
		}
	}

	// Token: 0x06000031 RID: 49 RVA: 0x000029F0 File Offset: 0x00000BF0
	internal static string smethod_1(string string_8, string string_9)
	{
		if (!(string_9 == "MD5"))
		{
			if (!(string_9 == "SHA1"))
			{
				if (!(string_9 == "SHA256"))
				{
					if (!(string_9 == "SIZE"))
					{
						return "Invalid Type";
					}
					try
					{
						using (File.OpenRead(string_8))
						{
							return new FileInfo(string_8).Length.ToString();
						}
					}
					catch
					{
						return "File Size Error";
					}
				}
				using (SHA256 sha = SHA256.Create())
				{
					try
					{
						using (FileStream fileStream2 = File.OpenRead(string_8))
						{
							byte[] array = sha.ComputeHash(fileStream2);
							StringBuilder stringBuilder = new StringBuilder();
							for (int i = 0; i < array.Length; i++)
							{
								stringBuilder.Append(array[i].ToString("X2"));
							}
							return stringBuilder.ToString();
						}
					}
					catch
					{
						return "SHA256 Error";
					}
				}
			}
			using (SHA1 sha2 = SHA1.Create())
			{
				try
				{
					using (FileStream fileStream3 = File.OpenRead(string_8))
					{
						byte[] array2 = sha2.ComputeHash(fileStream3);
						StringBuilder stringBuilder2 = new StringBuilder();
						for (int j = 0; j < array2.Length; j++)
						{
							stringBuilder2.Append(array2[j].ToString("X2"));
						}
						return stringBuilder2.ToString();
					}
				}
				catch
				{
					return "SHA1 Error";
				}
			}
		}
		string result;
		using (MD5 md = MD5.Create())
		{
			try
			{
				using (FileStream fileStream4 = File.OpenRead(string_8))
				{
					byte[] array3 = md.ComputeHash(fileStream4);
					StringBuilder stringBuilder3 = new StringBuilder();
					for (int k = 0; k < array3.Length; k++)
					{
						stringBuilder3.Append(array3[k].ToString("X2"));
					}
					result = stringBuilder3.ToString();
				}
			}
			catch
			{
				result = "MD5 Error";
			}
		}
		return result;
	}

	// Token: 0x0400001D RID: 29
	internal static string string_0 = "3307FC407D88BA40ABEAC87266F4558D";

	// Token: 0x0400001E RID: 30
	internal static string string_1 = "3B85FC7EC65D4E26720516866E72B240598CEDCE";

	// Token: 0x0400001F RID: 31
	internal static string string_2 = "B215110D42BDEC6069D1328E429C959F68C1BEE08333C4852BD3F5299B95173F";

	// Token: 0x04000020 RID: 32
	internal static string string_3 = "1741312";

	// Token: 0x04000021 RID: 33
	internal static string string_4 = "F33CBE589B769956284868104686CC2D";

	// Token: 0x04000022 RID: 34
	internal static string string_5 = "2FB0BE100DE03680FC4309C9FA5A29E69397A980";

	// Token: 0x04000023 RID: 35
	internal static string string_6 = "973FD70CE48E5AC433A101B42871680C51E2FEBA2AEEC3D400DEA4115AF3A278";

	// Token: 0x04000024 RID: 36
	internal static string string_7 = "653824";
}
